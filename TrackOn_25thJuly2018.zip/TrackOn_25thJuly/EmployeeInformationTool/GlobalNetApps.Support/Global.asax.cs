﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace GlobalNetApps.Support
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(MvcApplication));
        protected void Application_Start()
        {
            log4net.Config.XmlConfigurator.Configure();
            log4net.GlobalContext.Properties["user"] = new HttpContextUserNameProvider();
            log4net.GlobalContext.Properties["UserHostAddress"] = GetIPAddress();
            log4net.GlobalContext.Properties["MachineName"] = GetMachineName();
            log4net.GlobalContext.Properties["ApplicationName"] = "TrackOn";
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        protected void Application_BeginRequest()
        {           
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
        }
        //protected void Application_Error()
        //{
        //    var ex = Server.GetLastError();
        //    //log the error!
        //    Log.Error(ex);
        //}
        protected string GetIPAddress()
        {
            string host = System.Net.Dns.GetHostName();
            System.Net.IPAddress[] addresses = System.Net.Dns.GetHostEntry(host).AddressList;

            if (addresses.Count() > 1)
            {
                return addresses[1].ToString();
            }
            else
            {
                return "";
            }
        }
        protected string GetMachineName()
        {
            return System.Environment.MachineName;
        }
    }
    public class HttpContextUserNameProvider
    {
        public override string ToString()
        {
            HttpContext context = HttpContext.Current;
            if (context != null && context.User != null && context.User.Identity.IsAuthenticated)
            {
                return context.User.Identity.Name;
            }
            return "";
        }
    }
}
