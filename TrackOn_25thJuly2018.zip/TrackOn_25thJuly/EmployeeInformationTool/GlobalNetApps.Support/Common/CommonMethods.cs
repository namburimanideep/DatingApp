﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.Services.Repositories;
using GlobalNetApps.Support.Services.Entites;

namespace GlobalNetApps.Support.Common
{
    public class CommonMethods
    {
        public  string getUserName()
        {
            HttpContext context = HttpContext.Current;
            if (context != null && context.User != null && context.User.Identity.IsAuthenticated)
            {
                return context.User.Identity.Name.Trim().Replace(' ','.');
            }
            return "";
        }
    }
   
}