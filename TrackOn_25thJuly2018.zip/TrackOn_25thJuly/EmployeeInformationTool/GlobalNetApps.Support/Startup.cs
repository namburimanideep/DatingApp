﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(GlobalNetApps.TaxableTravel.Startup))]
namespace GlobalNetApps.TaxableTravel
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
