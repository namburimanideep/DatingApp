﻿$(document).ready(function () {
    $("#pageHeader").html("Employee Records");
    $("#nav li").each(function () {
        if ($(this).attr('id') == "liempProfile") {
            $(this).hide();
        }
    });
    grid = $('#CCgirdTable');
    $('#search_TER_No').keyup(function (e) {
        searchInGrid("CCgirdTable", "1", $(this).val());
        $('#search_cm_name').val("");
        $('#search_emp_id').val("");
        $('#search_CCCMonthly_ID').val("");
        $('#search_Status').val("");
        showall();
    });
    $('#search_cm_name').keyup(function (e) {
        searchInGrid("CCgirdTable", "2", $(this).val());
        $('#search_TER_No').val("");
        $('#search_emp_id').val("");
        $('#search_CCCMonthly_ID').val("");
        $('#search_Status').val("");
        showall();
    });
    $('#search_emp_id').keyup(function (e) {
        searchInGrid("CCgirdTable", "3", $(this).val());
        $('#search_TER_No').val("");
        $('#search_cm_name').val("");
        $('#search_CCCMonthly_ID').val("");
        $('#search_Status').val("");
        showall();
    });
    $('#search_CCCMonthly_ID').keyup(function (e) {
        searchInGrid("CCgirdTable", "4", $(this).val());
        $('#search_TER_No').val("");
        $('#search_cm_name').val("");
        $('#search_emp_id').val("");
        $('#search_Status').val("");
        showall();
    });
    $('#ddlStatus1').change(function (e) {
        searchStatusInGrid("CCgirdTable", "5", $(this).val());
        $('#search_TER_No').val("");
        $('#search_cm_name').val("");
        $('#search_emp_id').val("");
        $('#search_CCCMonthly_ID').val("");
        $('#search_Seq_num').val("");
        showall();
    });
    function searchStatusInGrid(tablename, coloumNumber, text1) {
        var tablename = $('#' + tablename);
        if (text1.length > 1 && text1 == "All") {
            tablename.find('tr').show();
        }
        else if (text1.length > 1) {
            tablename.find('tr:gt(1)').hide();
            tablename.find('tr').each(function (i) {
                var rowvalue = $(this).find('td:nth-child(' + coloumNumber + ')').text().toUpperCase();
                if ($.trim(rowvalue) == text1.toUpperCase())
                    $(this).show();
            });
        }
        else
            tablename.find('tr').show();
    }
    function showall() {
        if ($('#search_TER_No').val() == "" && $('#search_cm_name').val() == "" && $('#search_emp_id').val() == "" && $('#search_CCCMonthly_ID').val() == "" && $('#search_Status').val() == "") {
            showFullGrid("CCgirdTable");
        }
    }
    $("#txtToDate").datepicker({ format: 'mm/dd/yyyy' })
           .on('changeDate', function (ev) {
               $(this).datepicker('hide').keyup();
           });
    $("#txtToDate").on("cut copy paste", function (e) {
        e.preventDefault();
    });
    $("#txtFromDate").datepicker({ format: 'mm/dd/yyyy' })
                   .on('changeDate', function (ev) {
                       $(this).datepicker('hide').keyup();
                   });
    $("#txtFromDate").on("cut copy paste", function (e) {
        e.preventDefault();
    });
});
