﻿function searchInGrid(tablename, coloumNumber, text) {
    var tablename = $('#' + tablename);
    if (text.length > 1) {
        tablename.find('tr:gt(1)').hide();// hide data rows, except header row & first row       
        tablename.find('tr').each(function (i) { // iterate through all tablename rows           
            if ($(this).find('td:nth-child(' + coloumNumber + ')').text().toUpperCase().match(text.toUpperCase())) // check to see if search term matches Name column
                $(this).show(); // show matching row
        });
    }
    else
        tablename.find('tr').show(); // if no matching name is found, show all rows      
}
function showFullGrid(tablename) {
    var tablename = $('#' + tablename);
    tablename.find('tr:gt(1)').hide();// hide data rows, except header row & first row        
    tablename.find('tr').each(function (i) { // iterate through all tablename rows
        $(this).show(); // show matching row
    });
}
$(document).ready(function () {
    $('.calender').datepicker({
        showOptions: { speed: 'fast' },
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        maxDate: '0',
        gotoCurrent: true
    });
});

$(document).ready(function () {
    $('.listbox').multiselect({
        includeSelectAllOption: true
    });
});