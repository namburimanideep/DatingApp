﻿$(document).ready(function () {   
    grid = $('#AIgirdTable');
    $('#search_Incident').keyup(function (e) {
        searchInGrid("AIgirdTable", "1", $(this).val());
        $('#search_Description').val("");
        $('#search_Status').val("");
        $('#search_Category').val("");
        $('#search_AssignedDate').val("");
        $('#search_Priority').val("");
        $('#search_ApplicationName').val("");
        $('#search_SubCategory').val("");
        showall();
    });
    $('#search_Description').keyup(function (e) {
        searchInGrid("AIgirdTable", "2", $(this).val());
        $('#search_Incident').val("");
        $('#search_Status').val("");
        $('#search_Category').val("");
        $('#search_AssignedDate').val("");
        $('#search_Priority').val("");
        $('#search_ApplicationName').val("");
        $('#search_SubCategory').val("");
        showall();
    });
    $('#search_Status').keyup(function (e) {
        searchInGrid("AIgirdTable", "3", $(this).val());
        $('#search_Incident').val("");
        $('#search_Description').val("");
        $('#search_Category').val("");
        $('#search_AssignedDate').val("");
        $('#search_Priority').val("");
        $('#search_ApplicationName').val("");
        $('#search_SubCategory').val("");
        showall();
    });
    $('#search_Category').keyup(function (e) {
        searchInGrid("AIgirdTable", "4", $(this).val());
        $('#search_Incident').val("");
        $('#search_Description').val("");
        $('#search_Status').val("");
        $('#search_AssignedDate').val("");
        $('#search_Priority').val("");
        $('#search_ApplicationName').val("");
        $('#search_SubCategory').val("");
        showall();
    });
    $('#search_AssignedDate').keyup(function (e) {
        searchInGrid("AIgirdTable", "5", $(this).val());
        $('#search_Incident').val("");
        $('#search_Description').val("");
        $('#search_Status').val("");
        $('#search_Category').val("");
        $('#search_Priority').val("");
        $('#search_ApplicationName').val("");
        $('#search_SubCategory').val("");
        showall();
    });
    $('#search_Priority').keyup(function (e) {
        searchInGrid("AIgirdTable", "6", $(this).val());
        $('#search_Incident').val("");
        $('#search_Description').val("");
        $('#search_Status').val("");
        $('#search_Category').val("");
        $('#search_AssignedDate').val("");
        $('#search_ApplicationName').val("");
        $('#search_SubCategory').val("");
        showall();
    });
    $('#search_ApplicationName').keyup(function (e) {
        searchInGrid("AIgirdTable", "7", $(this).val());
        $('#search_Incident').val("");
        $('#search_Description').val("");
        $('#search_Status').val("");
        $('#search_Category').val("");
        $('#search_AssignedDate').val("");
        $('#search_Priority').val("");
        $('#search_SubCategory').val("");
        showall();
    });
    $('#search_SubCategory').keyup(function (e) {
        searchInGrid("AIgirdTable", "8", $(this).val());
        $('#search_Incident').val("");
        $('#search_Description').val("");
        $('#search_Status').val("");
        $('#search_Category').val("");
        $('#search_AssignedDate').val("");
        $('#search_ApplicationName').val("");
        $('#search_Priority').val("");
        showall();
    })
    function searchStatusInGrid(tablename, coloumNumber, text1) {
        var tablename = $('#' + tablename);
        if (text1.length > 1 && text1 == "All") {
            tablename.find('tr').show();
        }
        else if (text1.length > 1) {
            tablename.find('tr:gt(1)').hide();
            tablename.find('tr').each(function (i) {
                var rowvalue = $(this).find('td:nth-child(' + coloumNumber + ')').text().toUpperCase();
                if ($.trim(rowvalue) == text1.toUpperCase())
                    $(this).show();
            });
        }
        else
            tablename.find('tr').show();
    }
    function showall() {
        if ($('#search_TER_No').val() == "" && $('#search_cm_name').val() == "" && $('#search_emp_id').val() == "" && $('#search_CCCMonthly_ID').val() == "" && $('#search_Status').val() == "") {
            showFullGrid("AIgirdTable");
        }
    }   
});
