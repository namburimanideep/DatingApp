﻿$(document).ready(function () {
    $("#pageHeader").hide();
    $('#search-UserGroup').keyup(function (e)
    {
        searchInGrid("UserGroupsTable", "2", $(this).val());
    });
    $('#search-Application').keyup(function (e)
    {
        searchInGrid("UserAppsTable", "2", $(this).val());
        $('#search-Group').val("");
    });
    $('#search-Group').keyup(function (e) {
        searchInGrid("UserAppsTable", "3", $(this).val());
        $('#search-Application').val("");
    });
});
