﻿$(document).ready(function () {
    $("#pageHeader").html("Employee Details");
    $("#nav li").hide();
});
$('form').submit(function () {
    $(this).find('input:text').each(function () {
        $(this).val($.trim($(this).val()));
    })
});
$('#btnsubmit1').on('click', function () {   
    if ($("#txtEmpId").val().length == 0 && $("#txtUserName").val().length == 0 && $("#txtFullName").val().length == 0 && $("#txtEmailId").val().length == 0) {
        $("#lblwarning").show();
        return false;
    }
    else {
        $("#lblwarning").hide();
        return true;
    }
});