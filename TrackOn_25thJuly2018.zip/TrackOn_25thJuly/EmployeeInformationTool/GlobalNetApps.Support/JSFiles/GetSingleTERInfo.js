﻿$(document).ready(function () {
    $("#pageHeader").html("Employee TER details");
});
$('#ddlStatus').change(function (e) {
    searchInGrid("CCgirdTable", "11", $("#ddlStatus option:selected").text());
});
function searchInGrid(tablename, coloumNumber, text1) {
    var tablename = $('#' + tablename);
    if (text1.length > 1 && text1 == "All") {
        tablename.find('tr').show();
    }
    else if (text1.length > 1) {
        tablename.find('tr:gt(0)').hide();
        tablename.find('tr').each(function (i) {
            var rowvalue = $(this).find('td:nth-child(' + coloumNumber + ')').text().toUpperCase();
            if ($.trim(rowvalue) == text1.toUpperCase())
                $(this).show();
        });
    }
    else
        tablename.find('tr').show();
}