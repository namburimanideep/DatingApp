﻿

namespace GlobalNetApps.Support.Controllers
{
    using System.Web.Mvc;
    using System.Web.Security;

    public class ErrorController : Controller
    {
        // GET: Error
        public ActionResult AccessDenied()
        {
            return View();
        }

        public ActionResult Dashboard()
        {
            return Redirect(FormsAuthentication.LoginUrl);
        }
        public ActionResult InvalidToken()
        {
            return View();
        }
    }
}