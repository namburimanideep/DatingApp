﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using GlobalNetApps.Support.Models;
using GlobalNetApps.Support.Services.Repositories;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Common;
using System.Data;
using System;
using System.Globalization;
namespace GlobalNetApps.Support.Controllers
{
    [BaseAuthorize("DotNet")]
    public class EmployeeInformationController : Controller
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(EmployeeInformationController));
        ExcelMethods excel = new ExcelMethods();
        TypeConversion typeConversion = new TypeConversion();
        ServiceEmployeeInfo sInfo = new ServiceEmployeeInfo();
        public EmployeeInformationController()
        {
        }
        #region GetEmpInfo
        [HttpGet]
        public ActionResult GetEmpInfo()
        {
            try
            {
                Session["lstEmpInformation"] = null;
                if (TempData["noRecordsErrorMsg"] != null)
                {
                    ViewBag.ErrorMsg = TempData["noRecordsErrorMsg"];
                }
                else
                {
                    ViewBag.ErrorMsg = null;
                }
                return View();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        [HttpPost]
        public ActionResult GetEmpInfo(getEmpInfoViewModel info)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    Session["lstEmpInformation"] = null;
                    ViewBag.noRecordsErrorMsg = null;
                    Session["IsEntryValid"] = false;
                    List<EmpInfoViewModel> lstEFvm = new List<EmpInfoViewModel>();
                    List<EntityEmployeeInfo> lstInfo = sInfo.GetInfo(new getEmpInfoViewModel().creategetEmpInfo(info));
                    if (lstInfo.Count > 0)
                    {
                        Session["IsEntryValid"] = true;
                        List<string> lstEmpId = lstInfo.Select(x => x.EmployeeId.ToString()).ToList().Distinct().ToList();
                        string empIdbyComma = string.Empty;
                        string tomsEmpIDByComma = string.Empty;
                        foreach (var empid in lstEmpId)
                        {
                            empIdbyComma = empIdbyComma + "'" + empid + "'" + ",";
                            tomsEmpIDByComma = tomsEmpIDByComma + "'" + empid + "'" + ",";
                        }
                        empIdbyComma = " Where Seq_num in (SELECT max(seq_num)From corpcardcharges Where convert(Varchar(12), emp_id) in (" + empIdbyComma.Substring(0, empIdbyComma.Length - 1) + ") and insert_date >= DATEADD(MONTH, -6, GETDATE()) GROUP BY emp_id,TER_Num)  order by Seq_num desc";
                        tomsEmpIDByComma = "Where convert(Varchar(12), EmployeeID) in (" + tomsEmpIDByComma.Substring(0, tomsEmpIDByComma.Length - 1) + ") ";
                        Session["id"] = empIdbyComma;
                        List<CorpCardInfoViewModel> lstccvm = new CorpCardInfoViewModel().create(sInfo.GetCCInfo(empIdbyComma));
                        List<TomsViewModel> lsttoms = new TomsViewModel().create(sInfo.GetTomsInfo(tomsEmpIDByComma));
                        List<string> lstTERNum = lstccvm.Select(x => x.TER_Num.ToString()).ToList().Distinct().ToList();
                        EmpInfoViewModel EFvm = new EmpInfoViewModel().createEntityEmployeeInfo(lstInfo, lstccvm, lsttoms);
                        lstEFvm.Add(EFvm);
                        TempData["EmpInformation"] = EFvm;
                        Session["lstEmpInformation"] = EFvm;
                        ViewBag.noRecordsErrorMsg = null;
                        return RedirectToAction("empProfile");
                    }
                    else
                    {
                        TempData["noRecordsErrorMsg"] = "No records found in both Active directory & Employee Information tables";
                        return RedirectToAction("GetEmpInfo");
                    }
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }

        }
        #endregion
        #region empProfile
        [HttpGet]
        public ActionResult empProfile()
        {
            try
            {
                if (Session["lstEmpInformation"] != null)
                {
                    EmpInfoViewModel EFvm = (EmpInfoViewModel)Session["lstEmpInformation"];
                    List<string> lststatus = EFvm.Emp_CC.Select(x => x.Status.Trim()).ToList();
                    lststatus = lststatus.Distinct().ToList();
                    List<SelectListItem> lststatusddl = new List<SelectListItem>();
                    if (lststatus.Count > 1)
                    {
                        lststatusddl.Add(new SelectListItem { Text = "All", Value = "All", Selected = true });
                        foreach (var ststus in lststatus)
                        {
                            lststatusddl.Add(new SelectListItem { Text = ststus, Value = ststus, Selected = true });
                        }
                        ViewBag.Status = lststatusddl;
                    }
                    else
                    {
                        ViewBag.Status = null;
                    }
                    return View(EFvm);
                }
                else
                {
                    return RedirectToAction("GetEmpInfo");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View("GetEmpInfo");
            }
        }
        [HttpPost]
        public ActionResult empProfile(EmpInfoViewModel lstEFvm, FormCollection fm)
        {
            return View("GetEmpInfo");
        }
        #region methods
        public void GetADExcel()
        {
            try
            {
                if (Session["lstEmpInformation"] != null)
                {
                    EmpInfoViewModel eivm = (EmpInfoViewModel)Session["lstEmpInformation"];
                    DataTable dt = typeConversion.getDataTableforModel(eivm.Emp_AD.ToList());
                    dt.Columns.Remove("TableName");
                    dt.Columns.Remove("EmployeeType");
                    dt.Columns.Remove("EmployeeStatus");
                    dt.Columns.Remove("TerminationDate");
                    dt.Columns.Remove("BusinessUnit");
                    dt.Columns.Remove("HiringDate");
                    dt.Columns.Remove("ResigningDate");
                    dt.AcceptChanges();
                    excel.downloadexcel(dt, "ActiveDirectory");
                }
                else
                {
                    RedirectToAction("GetEmpInfo");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public void GetEIExcel()
        {
            try
            {
                if (Session["lstEmpInformation"] != null)
                {
                    EmpInfoViewModel eivm = (EmpInfoViewModel)Session["lstEmpInformation"];
                    DataTable dt = typeConversion.getDataTableforModel(eivm.Emp_EI.ToList());
                    dt.Columns.Remove("TableName");
                    dt.AcceptChanges();
                    excel.downloadexcel(dt, "EmloyeeInformation");
                }
                else
                {
                    RedirectToAction("GetEmpInfo");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public void GetCCExcel()
        {
            try
            {
                if (Session["lstEmpInformation"] != null)
                {
                    EmpInfoViewModel eivm = (EmpInfoViewModel)Session["lstEmpInformation"];
                    DataTable dt = typeConversion.getDataTableforModel(eivm.Emp_CC.ToList());
                    dt.Columns.Remove("bill_acct_num");
                    dt.Columns.Remove("charge_dt");
                    dt.Columns.Remove("insert_date");
                    dt.Columns.Remove("billdate");
                    dt.Columns.Remove("insert_dt");
                    dt.Columns.Remove("update_date");
                    dt.Columns.Remove("managername");
                    dt.Columns.Remove("manageremail");
                    dt.Columns.Remove("cardtype");
                    dt.Columns.Remove("businesspurposes");
                    dt.Columns.Remove("emp_type");
                    dt.Columns.Remove("dflt_grp_nm");
                    dt.AcceptChanges();
                    excel.downloadexcel(dt, "CorpCardCharges");
                }
                else
                {
                    RedirectToAction("GetEmpInfo");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public void GetTomsExcel()
        {
            try
            {
                if (Session["lstEmpInformation"] != null)
                {
                    EmpInfoViewModel eivm = (EmpInfoViewModel)Session["lstEmpInformation"];
                    DataTable dt = typeConversion.getDataTableforModel(eivm.Emp_Toms.ToList());
                    dt.AcceptChanges();
                    excel.downloadexcel(dt, "TomsInformation");
                }
                else
                {
                    RedirectToAction("GetEmpInfo");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        #endregion
        #endregion
        #region GetSingleTERInfo
        [HttpGet]
        public ActionResult GetSingleTERInfo(string TerNum = null)
        {
            try
            {
                if (TerNum == null)
                {
                    TerNum = Session["TerNum"].ToString();
                }
                Session["TerNum"] = TerNum.ToString();
                List<CorpCardInfoViewModel> lstccvm = new CorpCardInfoViewModel().create(sInfo.GetSingleTERInfo(TerNum));
                List<string> lststatus = lstccvm.Select(x => x.Status).ToList();
                lststatus = lststatus.Distinct().ToList();
                List<SelectListItem> lststatusddl = new List<SelectListItem>();
                if (lststatus.Count > 1)
                {
                    lststatusddl.Add(new SelectListItem { Text = "All", Value = "All", Selected = true });
                    foreach (var ststus in lststatus)
                    {
                        lststatusddl.Add(new SelectListItem { Text = ststus, Value = ststus, Selected = true });
                    }
                    ViewBag.Status = lststatusddl;
                }
                else
                {
                    ViewBag.Status = null;
                }
                return View("GetSingleTERInfo", lstccvm);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View("GetSingleTERInfo");
            }
        }
        public void GetSingleTerExcel()
        {
            try
            {
                if (Session["TerNum"] != null)
                {
                    List<CorpCardInfoViewModel> lstccvm = new CorpCardInfoViewModel().create(sInfo.GetSingleTERInfo(Session["TerNum"].ToString()));
                    excel.downloadexcelforModel(lstccvm, Session["TerNum"].ToString());
                }
                else
                {
                    RedirectToAction("GetEmpInfo");
                }
            }
            catch (Exception ex)
            {
                 Log.Error(ex.Message);
                 throw (ex);
            }
        }
        #endregion
        #region GetProfile
        [HttpGet]
        public ActionResult GetProfile(string userName = null)
        {
            try
            {
                if (userName == null)
                {
                    userName = Session["username"].ToString();
                }
                Session["username"] = userName.ToString();
                IdentityService_EmpInfo servEntity = sInfo.getProfile(userName);
                if (servEntity.UserName != null)
                {
                    IdentityServiceViewModel identityVM = new IdentityServiceViewModel().Create(servEntity);
                    List<string> lsServGrps = identityVM.groups.ToList();
                    Session["userGroups"] = identityVM.groups.ToList();
                    @ViewBag.groups = identityVM.groups.ToList();
                    List<ApplicationDetailsViewModel> lstAppDetails = new ApplicationDetailsViewModel().getAppDetails(sInfo.getApplicationDetails());
                    List<string> lstAlltAppNames = new List<string>();
                    List<string> lstAllAppgroups = new List<string>();
                    List<string> lstAppNames = new List<string>();
                    List<string> lstAppgroups = new List<string>();
                    lstAlltAppNames = lstAppDetails.Select(x => x.application).ToList();
                    lstAllAppgroups = lstAppDetails.Select(x => x.Groups).ToList();
                    @ViewBag.lstAppNames = null;
                    @ViewBag.lstAppgroups = null;
                    for (int i = 0; i < lstAllAppgroups.Count; i++)
                    {
                        if (lstAppDetails.Select(x => x.Groups).ToList()[i] != null)
                        {
                            List<string> lstCommon = lsServGrps.Intersect(lstAllAppgroups[i].Split(',').ToList()).ToList();
                            if (lstCommon.Count > 0)
                            {
                                string s = string.Empty;
                                foreach (var x in lstCommon)
                                {
                                    s = s + x + ",";
                                }
                                s = s.Substring(0, s.Length - 1);
                                lstAppgroups.Add(s);
                                lstAppNames.Add(lstAlltAppNames[i]);
                            }
                        }
                    }
                    @ViewBag.lstAppNames = lstAppNames;
                    @ViewBag.lstAppgroups = lstAppgroups;
                    Session["lstAppgroups"] = lstAppgroups;
                    Session["lstAppNames"] = lstAppNames;
                    return View(identityVM);
                }
                else
                {
                    return View("noServiceInfo");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        #region methods
        public DataTable ListToDatatable(List<string> inputlist, List<string> inputlist2 = null)
        {
            DataTable dt = new DataTable();
            try
            {
                dt.Columns.Add("S No", typeof(int));
                if (inputlist2 != null)
                {
                    dt.Columns.Add("App Name", typeof(string));
                    dt.Columns.Add("Group Name", typeof(string));
                }
                else
                {
                    dt.Columns.Add("Group Name", typeof(string));

                }

                for (int i = 0; i < inputlist.Count; i++)
                {
                    dt.Rows.Add();
                    dt.Rows[i][0] = i + 1;
                    dt.Rows[i][1] = inputlist[i];
                }
                if (inputlist2 != null)
                {
                    for (int i = 0; i < inputlist2.Count; i++)
                    {
                        dt.Rows[i][2] = inputlist2[2];
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }

            return dt;
        }
        public ActionResult GetGroupExcel()
        {
            try
            {
                excel.downloadexcel(ListToDatatable((List<string>)Session["userGroups"]), "UserGroups");
                return RedirectToAction("GetProfile");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View("GetProfile");
            }
        }
        public ActionResult GetAppGroupExcel()
        {
            try
            {
                excel.downloadexcel(ListToDatatable((List<string>)Session["lstAppNames"], (List<string>)Session["lstAppgroups"]), "UserAppGroups");
                return RedirectToAction("GetProfile");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View("GetProfile");
            }
        }
        #endregion
        #endregion
        [HttpGet]
        public ActionResult updateTERwithNewEmployeeId()
        {
            try
            {
                @ViewBag.CCCMonthlyId = null;
                @ViewBag.CCCMonthlyIderror = null;
                return View();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        [HttpPost]
        public ActionResult updateTERwithNewEmployeeId(new_oldEmpidForCorpCard empRecords)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    @ViewBag.ErrorMsg = "";
                    string query = System.IO.File.ReadAllText(System.Web.HttpContext.Current.Server.MapPath("~/queries/CorpCardEmpIdUpdateQuery.txt"));
                    query = query.Replace("11111", empRecords.new_empid);
                    query = query.Replace("22222", empRecords.old_empid);
                    List<EntityGetCCCMonthlyId> lstCCCMonthlyId = sInfo.updatCorpCardWithNewEmpid(empRecords.new_empid, empRecords.old_empid, query);

                    if (lstCCCMonthlyId.Count == 1 && (lstCCCMonthlyId[0].CCCMonthly_ID == 0 || lstCCCMonthlyId[0].CCCMonthly_ID == 1 || lstCCCMonthlyId[0].CCCMonthly_ID == 2))
                    {
                        if (lstCCCMonthlyId[0].CCCMonthly_ID == 0)
                        {
                            @ViewBag.ErrorMsg = "Old employee id doesnot exists";
                        }
                        if (lstCCCMonthlyId[0].CCCMonthly_ID == 1)
                        {
                            @ViewBag.ErrorMsg = "New employee id already exists";
                        }
                    }
                    else
                    {
                        List<string> lstCCCmtlyId = new List<string>();
                        string CCMonthlyId = string.Empty;
                        for (int i = 0; i < lstCCCMonthlyId.Count; i++)
                        {
                            lstCCCmtlyId.Add(lstCCCMonthlyId[i].CCCMonthly_ID.ToString());
                            CCMonthlyId = CCMonthlyId + "," + lstCCCMonthlyId[i].CCCMonthly_ID.ToString();
                        }
                        @ViewBag.CCCMonthlyId = CCMonthlyId.Substring(1, CCMonthlyId.Length - 1);
                    }
                    return View();
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                 Log.Error(ex.Message);
                return View();
            }

        }
        [HttpGet]
        public ActionResult VendorAddChange()
        {
            try
            {

                if (TempData["noRecordsErrorMsg1"] != null)
                {
                    ViewBag.ErrorMsg1 = TempData["noRecordsErrorMsg1"];
                }
                else
                {
                    ViewBag.ErrorMsg1 = null;
                }
                return View();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }

        }


        [HttpPost]
        public ActionResult VendorAddChange(vendorAddChange vendAC)
        {
            try
            {
                string query = System.IO.File.ReadAllText(System.Web.HttpContext.Current.Server.MapPath("~/queries/VendorAddorChange.txt"));
                query = query.Replace("0000", vendAC.vendorNew_empid);

                List<EntityVendorADDorMove> lstvendorInfo = sInfo.GetVendorInfo(vendAC.vendorNew_empid, query);
                vendorInformation venvm = new vendorInformation();
                if (lstvendorInfo.Count > 0)
                {
                    venvm = new vendorInformation().createVendorInfo(lstvendorInfo);

                }
                else
                {
                    TempData["noRecordsErrorMsg1"] = "No records found in Active directory,Employee Information and corpcard tables";
                    return RedirectToAction("VendorAddChange");
                }


                return View("VendorInformation", venvm);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
    }
}