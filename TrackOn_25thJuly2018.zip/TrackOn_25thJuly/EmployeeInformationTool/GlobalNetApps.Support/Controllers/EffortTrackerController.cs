﻿using System.Linq;
using System.Web.Mvc;
using GlobalNetApps.Support.Models;
using GlobalNetApps.Support.Services.Repositories;
using GlobalNetApps.Support.Common;
using System;
using System.Collections.Generic;
using System.Data;

namespace GlobalNetApps.Support.Controllers
{
    [BaseAuthorize("IncidentManagement")]
    public class EffortTrackerController : Controller
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(EffortTrackerController));
        ExcelMethods excel = new ExcelMethods();
        TypeConversion typeConversion = new TypeConversion();
        DateTimeMethods dtm = new DateTimeMethods();
        EffortTrackerService efforTrackerService = new EffortTrackerService();
        CommonMethods cm = new CommonMethods();
        public EffortTrackerController()
        {
        }
        #region Incident
        [HttpGet]
        public ActionResult ActiveIncidents()
        {
            return View(new IncidentViewModel().entityToVMMapping((efforTrackerService.getEntireTrackData(cm.getUserName(), 1))));
        }
        [HttpGet]
        public ActionResult ResolvedIncidents()
        {
            return View(new IncidentViewModel().entityToVMMapping((efforTrackerService.getEntireTrackData(cm.getUserName(), 2))));
        }
        public ActionResult downloadActiveIncidents()
        {
            List<string> ColumsToBeRemoved = new List<string>();
            ColumsToBeRemoved.Add("Id");
            ColumsToBeRemoved.Add("DailyUpdates");
            ColumsToBeRemoved.Add("RootCauseAndRemarks");
            ColumsToBeRemoved.Add("ResolutionCategory");
            ColumsToBeRemoved.Add("Severity");
            ColumsToBeRemoved.Add("AssignedTime");
            ColumsToBeRemoved.Add("ResolutionSLA_PHrs");
            ColumsToBeRemoved.Add("EffortInHours");
            ColumsToBeRemoved.Add("ResponseTimeSLA_PHrs");
            ColumsToBeRemoved.Add("Owner");
            ColumsToBeRemoved.Add("Track");
            ColumsToBeRemoved.Add("AlertType");
            ColumsToBeRemoved.Add("CreatedBy");
            ColumsToBeRemoved.Add("ResolvedDate");
            if (efforTrackerService.getTrackId(cm.getUserName())[0].value != "1")
            {
                ColumsToBeRemoved.Add("SubCategory");
            }
            excel.downloadexcelforModel((new IncidentViewModel().entityToVMMapping((efforTrackerService.getEntireTrackData(cm.getUserName(), 1)))), "TrackOn_ActiveIncidents", ColumsToBeRemoved);
            return RedirectToAction("ActiveIncidents");
        }
        public ActionResult downloadResolvedIncidents()
        {
            List<string> ColumsToBeRemoved = new List<string>();
            ColumsToBeRemoved.Add("Id");
            ColumsToBeRemoved.Add("DailyUpdates");
            ColumsToBeRemoved.Add("RootCauseAndRemarks");
            ColumsToBeRemoved.Add("ResolutionCategory");
            ColumsToBeRemoved.Add("Severity");
            ColumsToBeRemoved.Add("AssignedTime");
            ColumsToBeRemoved.Add("ResolutionSLA_PHrs");
            ColumsToBeRemoved.Add("EffortInHours");
            ColumsToBeRemoved.Add("ResponseTimeSLA_PHrs");
            ColumsToBeRemoved.Add("Owner");
            ColumsToBeRemoved.Add("Track");
            ColumsToBeRemoved.Add("AlertType");
            ColumsToBeRemoved.Add("CreatedBy");
            ColumsToBeRemoved.Add("AssignedDate");
            if (efforTrackerService.getTrackId(cm.getUserName())[0].value != "1")
            {
                ColumsToBeRemoved.Add("SubCategory");
            }
            excel.downloadexcelforModel((new IncidentViewModel().entityToVMMapping((efforTrackerService.getEntireTrackData(cm.getUserName(), 2)))), "TrackOn_ResolvedIncidents", ColumsToBeRemoved);
            return RedirectToAction("ResolvedIncidents");
        }
        [HttpGet]
        public ActionResult AddIncident()
        {
            try
            {
                getdata();
                if (TempData["AddIncidentMessage"] != null)
                {
                    int result = Convert.ToInt32(TempData["AddIncidentMessage"].ToString());
                    if (result == 1)
                    {
                        ViewBag.SuccessMsg = "Ticket added successfully";
                    }
                    else if (result > 1)
                    {
                        ViewBag.TicketErrorMsg = "Ticket with the same id already exist";
                    }
                    else
                    {
                        ViewBag.TicketErrorMsg = "Ticket has not been added";
                    }
                }
                return View();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        [HttpPost]
        public ActionResult AddIncident(IncidentViewModel addIncident)
        {
            try
            {
                if (efforTrackerService.getTrackId(cm.getUserName())[0].value != "2")
                {
                    addIncident.AlertType = "1";
                    addIncident.Severity = "1";
                    ModelState.Remove("AlertType");
                    ModelState.Remove("Severity");
                }
                if (ModelState.IsValid)
                {
                    if (!string.IsNullOrEmpty(addIncident.AssignedDate))
                    {
                        addIncident.AssignedDate = addIncident.AssignedDate + " " + addIncident.AssignedTime + ":00:000";
                    }
                    else
                    {
                        addIncident.AssignedDate = addIncident.AssignedDate + " " + "00:00:00:000";
                    }
                    TempData["AddIncidentMessage"] = efforTrackerService.addIncident(new IncidentViewModel().vmToEntityMapping(addIncident));
                    return RedirectToAction("AddIncident");
                }
                else
                {
                    getdata();
                    return View();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        [HttpGet]
        public ActionResult UpdateIncident()
        {
            @ViewBag.OpenIncidentForTrack = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getOpenIncidentForTrack(cm.getUserName()));
            @ViewBag.status = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getStatus());
            @ViewBag.RootCause = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getRootCause(cm.getUserName()));
            @ViewBag.Resolution = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getResolution(cm.getUserName()));
            try
            {
                if (TempData["UpdateIncidentMessage"] != null)
                {
                    int result = Convert.ToInt32(TempData["UpdateIncidentMessage"]);
                    if (result == 1)
                    {
                        ViewBag.SuccessMsg = "Ticket has been updated successfully";
                    }
                    else
                    {
                        ViewBag.TicketErrorMsg = "Ticket has not been updated";
                    }
                }
                return View(new UpdateIncidentViewModel());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View(new UpdateIncidentViewModel());
            }
        }
        [HttpPost]
        public ActionResult UpdateIncident(UpdateIncidentViewModel updateIncidentViewModel, string Command)
        {
            try
            {
                if (Command == null)
                {
                    updateIncidentViewModel = new UpdateIncidentViewModel().getVm(efforTrackerService.getHistory(updateIncidentViewModel.Id)[0]);
                    @ViewBag.OpenIncidentForTrack = new UpdateIncidentViewModel().getDDlWithSelectedItem((efforTrackerService.getOpenIncidentForTrack(cm.getUserName())), updateIncidentViewModel.Id);
                    @ViewBag.status = new UpdateIncidentViewModel().getDDlWithSelectedItem((efforTrackerService.getStatus()), Convert.ToInt32(updateIncidentViewModel.CurrentStatus));
                    @ViewBag.RootCause = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getRootCause(cm.getUserName()));
                    @ViewBag.Resolution = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getResolution(cm.getUserName()));
                    return View(updateIncidentViewModel);
                }
                else
                {
                    TempData["UpdateIncidentMessage"] = efforTrackerService.UpdateIncident(new UpdateIncidentViewModel().getEntity(updateIncidentViewModel));
                    return RedirectToAction("UpdateIncident");
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                @ViewBag.OpenIncidentForTrack = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getOpenIncidentForTrack(cm.getUserName()));
                @ViewBag.status = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getStatus());
                @ViewBag.RootCause = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getRootCause(cm.getUserName()));
                @ViewBag.Resolution = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getResolution(cm.getUserName()));
                return View(new UpdateIncidentViewModel());
            }
        }
        [HttpGet]
        public ActionResult SLA()
        {
            List<SLAViewModel> lstSLA = new SLAViewModel().EntityToVmMap(efforTrackerService.GetDetailsForSLA(cm.getUserName()));
            if (TempData["AddSLAMessage"] != null)
            {
                int result = Convert.ToInt32(TempData["AddSLAMessage"].ToString());
                if (result == 1)
                {
                    ViewBag.SuccessMsg = "SLA has been sucessfully updated";
                }
                else
                {
                    ViewBag.TicketErrorMsg = "SLA has not been updated";
                }
            }
            return View(lstSLA);
        }
        [HttpPost]
        public ActionResult SLA(List<SLAViewModel> lstSLA)
        {

            if (ModelState.IsValid)
            {
                TempData["AddSLAMessage"] = efforTrackerService.UpdateSLATimings(new SLAViewModel().VmToEntityMap(lstSLA));
                return RedirectToAction("SLA");
            }
            else
            {
                return View(lstSLA);
            }
        }
        #endregion

        #region Effort      
        [HttpGet]
        public ActionResult Efforts()
        {
            try
            {
                getdata();
                return View(new EffortViewModel().EntitytoVMMapping(efforTrackerService.getEfforts(cm.getUserName())));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        [HttpPost]
        public JsonResult AddEfforts(EffortViewModel efforts)
        {
            efforts = new EffortViewModel().EntitytoVMMapping(efforTrackerService.addEffort(new EffortViewModel().vmToEntityMapping(efforts)));
            return Json(efforts);
        }
        [HttpPost]
        public int UpdateEfforts(EffortViewModel efforts)
        {
            return efforTrackerService.updateEffort(new EffortViewModel().vmToEntityMapping(efforts));
        }
        [HttpPost]
        public int deleteEfforts(int Id)
        {
            return efforTrackerService.deleteEffort(Id);
        }
        #endregion

        #region Reports
        [HttpGet]
        public ActionResult GetDashBoard()
        {
            try
            {
                ViewBag.ErrorMsg = "";
                if (TempData["GetDashBoardMessage"] != null)
                {
                    ViewBag.ErrorMsg = "No data found with this inputs";
                }
                @ViewBag.TypeOfIncident = null;
                @ViewBag.Track = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getTracks()).Where(x => x.Value != "3").ToList();
                @ViewBag.Reports = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getReports());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return View();
        }
        [HttpPost]
        public ActionResult GetDashBoard(GetDashBoardViewModel dbvm, string Command)
        {
            try
            {
                @ViewBag.TypeOfIncident = null;
                if (Command == null)
                {
                    ModelState.Remove("AssignedFromDate");
                    ModelState.Remove("AssignedToDate");
                    ModelState.Remove("track");
                    ModelState.Remove("Type");
                    ModelState.Remove("status");
                    ModelState.Remove("Reports");
                    if (ModelState.IsValid)
                    {
                        @ViewBag.status = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getStatus());
                        @ViewBag.TypeOfIncident = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getTypeOfIncident(Convert.ToInt32(dbvm.track)));
                        @ViewBag.Track = new UpdateIncidentViewModel().getDDlWithSelectedItem(efforTrackerService.getTracks(), Convert.ToInt32(dbvm.track)).Where(x => x.Value != "3").ToList();
                        @ViewBag.Reports = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getReports());
                    }
                    else
                    {
                        @ViewBag.status = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getStatus());
                        @ViewBag.TypeOfIncident = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getTypeOfIncident(Convert.ToInt32(dbvm.track)));
                        @ViewBag.Track = new UpdateIncidentViewModel().getDDlWithSelectedItem(efforTrackerService.getTracks(), Convert.ToInt32(dbvm.track)).Where(x => x.Value != "3").ToList();
                        @ViewBag.Reports = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getReports());
                    }
                }
                else
                {
                    if (ModelState.IsValid)
                    {
                        DataTable dt = new DataTable();
                        List<string> ColumsToBeRemoved = new List<string>();
                        if (dbvm.Reports == "1")
                        {
                            ColumsToBeRemoved.Add("ID");
                            ColumsToBeRemoved.Add("createdBy");
                            if (dbvm.track != "2")
                            {
                                ColumsToBeRemoved.Add("AlertType");
                            }
                            var lst = efforTrackerService.getDashBoard(new GetDashBoardViewModel().getEntity(dbvm));
                            if (lst.Count > 0)
                            {
                                excel.downloadexcelforModel((lst), "TrackOn_Report", ColumsToBeRemoved);
                            }
                            else
                            {
                                TempData["GetDashBoardMessage"] = 0;
                            }
                        }
                        else
                        {
                            var lst = efforTrackerService.getReport(new GetDashBoardViewModel().getEntity(dbvm));
                            if (lst.Count > 0)
                            {
                                if (dbvm.Reports == "2")
                                {
                                    ColumsToBeRemoved.Add("Name");
                                    ColumsToBeRemoved.Add("CurrentStatus");
                                }
                                else if (dbvm.Reports == "3")
                                {
                                    ColumsToBeRemoved.Add("Name");
                                }
                                else if (dbvm.Reports == "4")
                                {
                                    ColumsToBeRemoved.Add("CurrentStatus");
                                    ColumsToBeRemoved.Add("AssignedDate");
                                }
                                else if (dbvm.Reports == "5")
                                {
                                    ColumsToBeRemoved.Add("CurrentStatus");
                                }
                                else if (dbvm.Reports == "6")
                                {
                                    ColumsToBeRemoved.Add("CurrentStatus");
                                    ColumsToBeRemoved.Add("AssignedDate");
                                    ColumsToBeRemoved.Add("Name");
                                }
                                excel.downloadexcelforModel((lst), "TrackOn_Report", ColumsToBeRemoved);
                            }
                            else
                            {
                                TempData["GetDashBoardMessage"] = 0;
                            }
                        }
                        @ViewBag.status = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getStatus());
                        @ViewBag.TypeOfIncident = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getTypeOfIncident(Convert.ToInt32(dbvm.track)));
                        @ViewBag.Track = new UpdateIncidentViewModel().getDDlWithSelectedItem(efforTrackerService.getTracks(), Convert.ToInt32(dbvm.track)).Where(x => x.Value != "3").ToList();
                        @ViewBag.Reports = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getReports());
                        return RedirectToAction("GetDashBoard", false);
                    }
                    else
                    {
                        @ViewBag.status = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getStatus());
                        @ViewBag.TypeOfIncident = new GetDashBoardViewModel().getDDlSelectListItem(efforTrackerService.getTypeOfIncident(Convert.ToInt32(dbvm.track)));
                        @ViewBag.Track = new UpdateIncidentViewModel().getDDlWithSelectedItem(efforTrackerService.getTracks(), Convert.ToInt32(dbvm.track)).Where(x => x.Value != "3").ToList();
                        @ViewBag.Reports = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getReports());
                        return View();
                    }
                }
                return View();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        #endregion

        #region CommonMethods
        public void getdata()
        {
            try
            {
                @ViewBag.status = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getStatus());
                @ViewBag.Priority = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getPriority());
                @ViewBag.TypeOfIncident = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getTypeOfIncident(cm.getUserName()));
                @ViewBag.Name = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getName(cm.getUserName()));
                @ViewBag.Application = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getApplication(cm.getUserName()));
                @ViewBag.Track = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getTracks());
                @ViewBag.Resolution = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getResolution(cm.getUserName()));
                @ViewBag.Effort = new IncidentViewModel().getDDLhours();
                @ViewBag.RootCause = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getRootCause(cm.getUserName()));
                @ViewBag.IncidentDropDown = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getIncidentDropDown(cm.getUserName()));
                @ViewBag.EffortType = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getEffortType(cm.getUserName()));
                // @ViewBag.EffortHistory = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getEffortHistory());
                @ViewBag.Severity = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getSeverity());
                @ViewBag.TrackId = efforTrackerService.getTrackId(cm.getUserName())[0].value;
                @ViewBag.AlertType = new IncidentViewModel().getDDlSelectListItem(efforTrackerService.getAlertType());
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
        }
        #endregion
    }
}