﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using GlobalNetApps.Support.Models;
using GlobalNetApps.Support.Services.Repositories;
using System.Web.Security;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Generic;
using GlobalNetApps.Support.Common;
namespace GlobalNetApps.Support.Controllers
{
    public class AccountController : Controller
    {
        EffortTrackerService efforTrackerService = new EffortTrackerService();
        CommonMethods cm = new CommonMethods();
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(AccountController));
        #region login
        [HttpGet]
        public ActionResult login()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        [HttpPost]
        public ActionResult login(LoginViewModel logInVM)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string servicename = string.Empty;
                    AccountService ac = new AccountService();
                    servicename = ac.validateLogin(logInVM.Username, logInVM.password);
                    if (servicename != string.Empty)
                    {
                        if (efforTrackerService.getTrackId(logInVM.Username.Trim().ToString()).Count > 0)
                        {
                            @ViewBag.logInFailure = "";
                            createCookie(servicename.Substring((servicename.IndexOf(",") + 1), (servicename.Length - (servicename.IndexOf(",") + 1))) + " " + servicename.Substring(0, servicename.IndexOf(",")), "");
                            return RedirectToAction("AddIncident", "EffortTracker");
                        }
                        else
                        {
                            Log.Info("Unauthorized user with valid AD credentials:" + logInVM.Username);
                            return RedirectToAction("AccessDenied", "Error");
                        }
                    }
                    else
                    {
                        Log.Info("Invalid Login for user name " + logInVM.Username);
                        @ViewBag.logInFailure = "Invalid Login. Please enter a valid username and password";
                    }
                    return View(logInVM);
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return View();
            }
        }
        public void createCookie(string username, string userRoles)
        {
            try
            {
                FormsAuthentication.SetAuthCookie(username, false);
                FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                    1,
                    username,
                    DateTime.Now,
                    DateTime.Now.AddMinutes(30),
                    false,
                    efforTrackerService.getRoles(username.Trim().Replace(' ', '.'))[0].value);
                string formscookiestr = FormsAuthentication.Encrypt(authTicket);
                HttpCookie formcookies = new HttpCookie(FormsAuthentication.FormsCookieName, formscookiestr);
                Response.Cookies.Add(formcookies);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
        }
        #endregion
    }
}