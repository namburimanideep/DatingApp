﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using GlobalNetApps.Support.Models;
using GlobalNetApps.Support.Services.Repositories;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Common;
using System.Data;
using System;
using System.Globalization;
using System.IO;
using System.Web;

namespace GlobalNetApps.Support.Controllers
{
    [BaseAuthorize("IncidentManagement")]
    public class DefectTrackerController : Controller
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(DefectTrackerController));

        DefectTrackerService defectTrackerService = new DefectTrackerService();
        EffortTrackerService efforTrackerService = new EffortTrackerService();
        CommonMethods cm = new CommonMethods();
        [HttpGet]
        public ActionResult LogDefect()
        {
            if (TempData["AddDefectMessage"] != null)
            {
                int result = Convert.ToInt32(TempData["AddDefectMessage"].ToString());
                if (result == 1)
                {
                    ViewBag.SuccessMsg = "Defect added successfully";
                }
                else
                {
                    ViewBag.ErrorMsg = "Defect has not been added";
                }
            }
            return View();
        }
        [HttpPost]
        public ActionResult LogDefect(LogDefectViewModel logDefectViewModel)
        {

            if (ModelState.IsValid)
            {
                TempData["AddDefectMessage"] = defectTrackerService.UploadDefects(new LogDefectViewModel().getEntity(logDefectViewModel)).Count();
                if (efforTrackerService.getTrackId(cm.getUserName())[0].value == "1")
                {
                    return RedirectToAction("DefectTracker");
                }
                else
                {
                    return RedirectToAction("LogDefect");
                }
            }
            else
            {
                return View();
            }
           // return View();
        }
        [HttpGet]
        public ActionResult DefectTracker()
        {
            return View(new DefectTrackerViewModel().EntitytoVMMapping(defectTrackerService.getDefects()));
        }

        [HttpPost]
        public ActionResult DefectTracker(HttpPostedFileBase postedFile)
        {
            byte[] bytes;
            using (BinaryReader br = new BinaryReader(postedFile.InputStream))
            {
                bytes = br.ReadBytes(postedFile.ContentLength);
            }
            List<EntityDefects> lstimages = new List<EntityDefects>();
            EntityDefects EntyDefect = new EntityDefects();
            EntyDefect.Name = Path.GetFileName(postedFile.FileName);
            EntyDefect.ContentType = postedFile.ContentType;
            EntyDefect.Data = bytes;
            defectTrackerService.UploadDefects(EntyDefect);
            return RedirectToAction("DefectTracker");

        }
    }
}