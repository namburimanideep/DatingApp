﻿using System;
using System.Web.Mvc;
using System.Web.Security;
namespace GlobalNetApps.Support.Controllers
{
    public class LogOffController : Controller
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(LogOffController));
        [Route("LogOff")]
        public ActionResult LogOff()
        {
            try
            {
                FormsAuthentication.SignOut();
            }
             catch(Exception ex)
            {
                Log.Error(ex.Message);
            }
            return View();
        }
    }
}