﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using GlobalNetApps.Support.Models;
using GlobalNetApps.Support.Services.Repositories;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Common;
using System.Data;
using System;
using System.Globalization;

namespace GlobalNetApps.Support.Controllers
{
    //[BaseAuthorize]
    public class MasterDataController : Controller
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(MasterDataController));
        MasterDataService masterDataService = new MasterDataService();
        public ActionResult Associates()
        {
            return View(new AssociatesViewModel().getAssociates(masterDataService.GetAssociates()));
        }

        [HttpPost]
        public JsonResult Insertassociates(AssociatesViewModel associates)
        {
            //using (associatessEntities entities = new associatessEntities())
            //{
            //    entities.associatess.Add(associates);
            //    entities.SaveChanges();
            //}

            return Json(associates);
        }

        [HttpPost]
        public ActionResult Updateassociates(AssociatesViewModel associates)
        {
           // masterDataService.DeleteAssociates(new AssociatesViewModel().getAssociatesEntity(associates));
            //using (associatessEntities entities = new associatessEntities())
            //{
            //    associates updatedassociates = (from c in entities.associatess
            //                                where c.associatesId == associates.associatesId
            //                                select c).FirstOrDefault();
            //    updatedassociates.Name = associates.Name;
            //    updatedassociates.Country = associates.Country;
            //    entities.SaveChanges();
            //}

            return new EmptyResult();
        }

        [HttpPost]
        public int Deleteassociates(int Id)
        {
           // masterDataService.DeleteAssociates(Id);
            return masterDataService.DeleteAssociates(Id);
            //return new EmptyResult();
        }
    }
}