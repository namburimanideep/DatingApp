﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.Web.Mvc;

namespace GlobalNetApps.Support.Models
{
    public class TomsViewModel
    {
        public int EmployeeID { get; set; }
        public string UserName { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string EmployeePositionID { get; set; }
        public string SupervisorPositionID { get; set; }
        public string VPPositionID { get; set; }
        public string Location { get; set; }
        public string HireDate { get; set; }
        public string TerminationDate { get; set; }
        public string CompanyCode { get; set; }
        public string DateTimeUploaded { get; set; }
        public string EmployeeType { get; set; }
        public List<TomsViewModel> create(List<EntityTomsInfo> lstEntyToms)
        {
            List<TomsViewModel> lstTomsvm = new List<TomsViewModel>();
            foreach (var entyToms in lstEntyToms)
            {
                TomsViewModel tomsvm = new TomsViewModel();
                tomsvm.EmployeeID = entyToms.EmployeeID;
                tomsvm.UserName = entyToms.UserName;
                tomsvm.LastName = entyToms.LastName;
                tomsvm.FirstName = entyToms.FirstName;
                tomsvm.EmployeePositionID = entyToms.EmployeePositionID;
                tomsvm.SupervisorPositionID = entyToms.SupervisorPositionID;
                tomsvm.VPPositionID = entyToms.VPPositionID;
                tomsvm.Location = entyToms.Location;
                tomsvm.HireDate = entyToms.HireDate;
                tomsvm.TerminationDate = entyToms.TerminationDate;
                tomsvm.CompanyCode = entyToms.CompanyCode;
                tomsvm.DateTimeUploaded = entyToms.DateTimeUploaded;
                tomsvm.EmployeeType = entyToms.EmployeeType;
                lstTomsvm.Add(tomsvm);
            }
            return lstTomsvm;
        }

    }

}