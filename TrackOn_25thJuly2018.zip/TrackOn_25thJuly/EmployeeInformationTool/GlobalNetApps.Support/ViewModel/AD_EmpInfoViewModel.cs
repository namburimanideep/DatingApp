﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GlobalNetApps.Support.Models
{
    public class AD_EmpInfoViewModel
    {
        public string TableName { get; set; }
        public int EmployeeId { get; set; }
        public string mail { get; set; }
        public string UserName { get; set; }
        public string EmployeeType { get; set; }
        public string EmployeeStatus { get; set; }
        public string TerminationDate { get; set; }
        public string Company { get; set; }
        public string BusinessUnit { get; set; }
        public string HiringDate { get; set; }
        public string ResigningDate { get; set; }
        public string FullName { get; set; }
    }
}