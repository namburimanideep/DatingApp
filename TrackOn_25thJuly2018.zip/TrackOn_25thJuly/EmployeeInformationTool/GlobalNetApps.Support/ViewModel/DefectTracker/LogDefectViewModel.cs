﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;
using GlobalNetApps.Support.Common;
using System.IO;
using System.Drawing.Imaging;
namespace GlobalNetApps.Support.Models
{
    public class LogDefectViewModel
    {
        CommonMethods cm = new CommonMethods();
        [Required(ErrorMessage = "Please enter defect description.")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Please select file.")]      
        [ValidateFile(ErrorMessage = "Please select a PNG or JPEG files smaller than 1MB")]
        public HttpPostedFileBase PostedFile { get; set; }

        public EntityDefects getEntity(LogDefectViewModel logDefectViewModel)
        {
            EntityDefects entityDefects = new EntityDefects();
            byte[] bytes;
            using (BinaryReader br = new BinaryReader(logDefectViewModel.PostedFile.InputStream))
            {
                bytes = br.ReadBytes(logDefectViewModel.PostedFile.ContentLength);
            }
            entityDefects.Data = bytes;
            entityDefects.Name = Path.GetFileName(logDefectViewModel.PostedFile.FileName);
            entityDefects.ContentType = logDefectViewModel.PostedFile.ContentType;
            entityDefects.Description = logDefectViewModel.Description;
            entityDefects.CreatedBy = cm.getUserName();
            return entityDefects;
           
        }

    }
    public class ValidateFileAttribute : RequiredAttribute
    {
        public override bool IsValid(object value)
        {
            var file = value as HttpPostedFileBase;
            try
            {
                var supportedTypes = new[] { "jpeg", "png","jpg" };
                var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1).ToLower();
                if (!supportedTypes.Contains(fileExt))
                {
                    ErrorMessage = "File Extension Is InValid.Kindly upload JPEG or PNG files";
                    return false;
                }
                else if (file.ContentLength > 1 * 1024 * 1024)
                {
                    ErrorMessage = "File size Should Be less then 1MB";
                    return false;
                }
                else
                {
                    ErrorMessage = "File Is Successfully Uploaded";
                    return true;
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = "please slect a file to upload";
                return false;
            }
        }
    }
}