﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;
using GlobalNetApps.Support.Common;
using System.Drawing.Imaging;

namespace GlobalNetApps.Support.Models
{
    public class DefectTrackerViewModel
    {
        public int id { get; set; }
        public string Description { get; set; }
        public string Name { get; set; }
        public string ContentType { get; set; }
        public byte[] Data { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public string IsActive { get; set; }

        public List<DefectTrackerViewModel> EntitytoVMMapping(List<EntityDefects> defectEntity)
        {
            List<DefectTrackerViewModel> lstDefectTrackerViewModel = new List<DefectTrackerViewModel>();
            for (int i = 0; i < defectEntity.Count; i++)
            {
                DefectTrackerViewModel defectTrackerViewModel = new DefectTrackerViewModel();

                defectTrackerViewModel.id = defectEntity[i].id;
                defectTrackerViewModel.Description = defectEntity[i].Description;
                defectTrackerViewModel.Name = defectEntity[i].Name;
                defectTrackerViewModel.ContentType = defectEntity[i].ContentType;
                defectTrackerViewModel.Data = defectEntity[i].Data;
                defectTrackerViewModel.CreatedBy = defectEntity[i].CreatedBy;
                defectTrackerViewModel.CreatedDateTime = defectEntity[i].CreatedDateTime;
                defectTrackerViewModel.LastUpdatedBy = defectEntity[i].LastUpdatedBy;
                defectTrackerViewModel.IsActive = defectEntity[i].IsActive;
                // defectTrackerViewModel.ContentType = defectEntity[i].ContentType;
                lstDefectTrackerViewModel.Add(defectTrackerViewModel);
            }
            return lstDefectTrackerViewModel;
        }

    }  
}