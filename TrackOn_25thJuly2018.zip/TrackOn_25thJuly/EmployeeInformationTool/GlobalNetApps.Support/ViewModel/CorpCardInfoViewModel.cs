﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;
using System.Web.Mvc;

namespace GlobalNetApps.Support.Models
{
    public class CorpCardInfoViewModel
    {
        public int TER_Num { get; set; }
        public int Seq_num { get; set; }
        public string cm_name { get; set; }
        public int emp_id { get; set; }
        public string bill_acct_num { get; set; }
        public string charge_dt { get; set; }
        public string insert_date { get; set; }
        public string billdate { get; set; }
        public string insert_dt { get; set; }
        public string Status { get; set; }
        public string CCCMonthly_ID { get; set; }
        public string update_date { get; set; }
        public string managername { get; set; }
        public string manageremail { get; set; }
        public string cardtype { get; set; }
        public string businesspurposes { get; set; }
        public string emp_type { get; set; }
        public string dflt_grp_nm { get; set; }
        public string amount { get; set; }
        public string localamount { get; set; }
        public string description { get; set; }
        public List<CorpCardInfoViewModel> create(List<EntityCorpCardInfo> lstEntyCC)
        {
            List<CorpCardInfoViewModel> lstCCvm = new List<CorpCardInfoViewModel>();
            foreach (var entyCC in lstEntyCC)
            {
                CorpCardInfoViewModel ccvm = new CorpCardInfoViewModel();
                ccvm.TER_Num = entyCC.TER_Num;
                ccvm.Seq_num = entyCC.Seq_num;
                ccvm.cm_name = entyCC.cm_name;
                ccvm.emp_id = entyCC.emp_id;
                ccvm.bill_acct_num = entyCC.bill_acct_num;
                ccvm.charge_dt = entyCC.charge_dt;
                ccvm.insert_date = entyCC.insert_date;
                ccvm.billdate = entyCC.billdate;
                ccvm.insert_dt = entyCC.insert_dt;
                ccvm.Status = entyCC.Status;
                ccvm.CCCMonthly_ID = entyCC.CCCMonthly_ID;
                ccvm.update_date = entyCC.update_date;
                ccvm.managername = entyCC.managername;
                ccvm.manageremail = entyCC.manageremail;
                ccvm.cardtype = entyCC.cardtype;
                ccvm.businesspurposes = entyCC.businesspurposes;
                ccvm.emp_type = entyCC.emp_type;
                ccvm.dflt_grp_nm = entyCC.dflt_grp_nm;
                ccvm.localamount = entyCC.localamount;
                ccvm.amount = entyCC.amount;
                ccvm.description = entyCC.description;
                lstCCvm.Add(ccvm);
            }
            return lstCCvm;
        }
    }
}
