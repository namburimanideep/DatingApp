﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;

namespace GlobalNetApps.Support.Models
{
    public class getEmpInfoViewModel
    {        
        [RegularExpression("^[0-9]*$", ErrorMessage = "Enter a valid employee Id")]
        public string EmpId { get; set; }
        [StringLength(50, MinimumLength = 0, ErrorMessage = "Max of 50 characters allowed")]
        [RegularExpression("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$", ErrorMessage = "Enter a valid email id")]
        public string EmailId { get; set; }
        [StringLength(40, MinimumLength = 0, ErrorMessage = "Max of 40 characters allowed")]
        //[RegularExpression("^[a-zA-Z]+(([\\.][a-zA-Z])?[a-zA-Z]*)*$", ErrorMessage = "Enter a valid name")]
        //[RegularExpression("^(?=[^,]+,[^,]+$)[a-zA-Z,]{1,20}$", ErrorMessage = "Enter a valid name")]
        public string UserName { get; set; }
        [StringLength(50, MinimumLength = 0, ErrorMessage = "Max of 50 characters allowed")]
        [RegularExpression("^[a-zA-Z]+(([\\.][a-zA-Z])?[a-zA-Z]*)*$", ErrorMessage = "Enter a valid name")]
        public string FullName { get; set; }
        public EntityGetEmpInfo creategetEmpInfo(getEmpInfoViewModel GetInfo)
        {
            EntityGetEmpInfo info = new EntityGetEmpInfo();
            if(!string.IsNullOrEmpty(GetInfo.EmpId))
            {
                info.EmpId = Convert.ToInt32(GetInfo.EmpId);
            }
            info.UserName = GetInfo.UserName;
            info.FullName = GetInfo.FullName;
            info.EmailId = GetInfo.EmailId;
            return info;
        }
    }


}