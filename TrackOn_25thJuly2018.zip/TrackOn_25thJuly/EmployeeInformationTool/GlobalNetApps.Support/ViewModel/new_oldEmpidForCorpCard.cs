﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;

namespace GlobalNetApps.Support.Models
{
    public class new_oldEmpidForCorpCard
    {
        [RegularExpression("^[0-9]*$", ErrorMessage = "Enter a valid employee Id")]
        public string new_empid { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Enter a valid employee Id")]
        public string old_empid { get; set; }        
    }
}