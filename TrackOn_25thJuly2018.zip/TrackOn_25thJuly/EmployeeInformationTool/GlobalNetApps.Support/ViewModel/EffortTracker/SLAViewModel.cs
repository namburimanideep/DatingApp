﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;
using GlobalNetApps.Support.Common;


namespace GlobalNetApps.Support.Models
{
    public class SLAViewModel
    {
        CommonMethods cm = new CommonMethods();
        public string IncidentID { get; set; }
        public string IncidentDescription { get; set; }
        [Required(ErrorMessage = "Please enter a response time in minutes")]
        [Range(0, 3000, ErrorMessage = "Please enter minutes")]        
        public string ResolutionSLA_PHrs { get; set; }
        [Required(ErrorMessage = "Please enter a resolution time in minutes")]
        [Range(0, 3000, ErrorMessage = "Please enter minutes")]
        public string ResponseTimeSLA_PHrs { get; set; }
        public int ID { get; set; }
        public List<SLAViewModel> EntityToVmMap(List<EntitySLA> entySLA)
        {
            List<SLAViewModel> lstSLA = new List<SLAViewModel>();
            for (int i = 0; i < entySLA.Count; i++)
            {
                SLAViewModel SLAvm = new SLAViewModel();
                SLAvm.IncidentID = entySLA[i].IncidentID;
                SLAvm.IncidentDescription = entySLA[i].IncidentDescription;
                SLAvm.ID = entySLA[i].ID;
                SLAvm.ResponseTimeSLA_PHrs = entySLA[i].ResponseTimeSLA_PHrs;
                SLAvm.ResolutionSLA_PHrs = entySLA[i].ResolutionSLA_PHrs;
                lstSLA.Add(SLAvm);
            }
            return lstSLA;
        }
        public List<EntitySLA> VmToEntityMap(List<SLAViewModel> vmSLA)
        {
            List<EntitySLA> lstSLA = new List<EntitySLA>();
            for (int i = 0; i < vmSLA.Count; i++)
            {
                EntitySLA entySLA = new EntitySLA();
                entySLA.ResolutionSLA_PHrs = vmSLA[i].ResolutionSLA_PHrs;
                entySLA.ResponseTimeSLA_PHrs = vmSLA[i].ResponseTimeSLA_PHrs;
                entySLA.IncidentID = vmSLA[i].IncidentID;
                entySLA.ID = vmSLA[i].ID;
                entySLA.CreatedBy = cm.getUserName();
                lstSLA.Add(entySLA);
            }
            return lstSLA;
        }
    }
}

