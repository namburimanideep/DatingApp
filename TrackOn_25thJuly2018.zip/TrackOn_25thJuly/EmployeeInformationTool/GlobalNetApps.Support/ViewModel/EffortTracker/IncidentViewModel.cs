﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Common;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace GlobalNetApps.Support.Models
{
    public class IncidentViewModel
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(IncidentViewModel));
        CommonMethods cm = new CommonMethods();
        public int Id { get; set; }
        [Required]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Field must not exceed more than 30 characters")]
        public string IncidentId { get; set; }
        [Required]
        public string IncidentDescription { get; set; }
        // [Required]
        public string DailyUpdates { get; set; }
        [Required]
        [Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string Category { get; set; }
        public string RootCauseAndRemarks { get; set; }
        public string ResolutionCategory { get; set; }
        //[Required]
        //[Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string CurrentStatus { get; set; }
        [Required]
        [Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string Severity { get; set; }
        [Required]
        [Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string Priority { get; set; }
        [Required]
        public string AssignedDate { get; set; }
        [RegularExpression("^([0-1][0-9]|[2][0-3]):([0-5][0-9])$", ErrorMessage = "Please enter time in 24 Hours(HH:MM) format")]
        public string AssignedTime { get; set; }
        [Required]
        [Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string ApplicationName { get; set; }
        public string ResolutionSLA_PHrs { get; set; }
        public string EffortInHours { get; set; }
        public string ResponseTimeSLA_PHrs { get; set; }
        [Required]
        [Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string Owner { get; set; }
        public string Track { get; set; }
        [Required]
        [Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string AlertType { get; set; }
        public string CreatedBy { get; set; }
        public string SubCategory { get; set; }
        public string ResolvedDate { get; set; }


        public List<SelectListItem> getDDlSelectListItem(List<EntityMasterTable> lstEMT)
        {
            List<SelectListItem> selectItems = new List<SelectListItem>();
            try
            {
                for (int i = 0; i < lstEMT.Count; i++)
                {
                    if (i == 0)
                    {
                        SelectListItem listItemSelect = new SelectListItem();
                        listItemSelect.Value = "0";
                        listItemSelect.Text = "--Select one--";
                        selectItems.Add(listItemSelect);
                    }
                    SelectListItem listItem = new SelectListItem();
                    listItem.Value = lstEMT[i].id.ToString();
                    listItem.Text = lstEMT[i].value.ToString();
                    selectItems.Add(listItem);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return selectItems;
        }
        public List<dropDownViewModel> getDDLhours()
        {
            List<dropDownViewModel> lstDDL = new List<dropDownViewModel>();
            for (int i = 1; i < 25; i++)
            {
                dropDownViewModel ddl = new dropDownViewModel();
                ddl.data = i.ToString();
                lstDDL.Add(ddl);
            }
            return lstDDL;
        }
        public EntityIncident vmToEntityMapping(IncidentViewModel incidentVm)
        {
            //EntityIncidentDetails InDetails = lstIncidentDetails[0];
            EntityIncident entityIncident = new EntityIncident();
            entityIncident.IncidentId = incidentVm.IncidentId;
            entityIncident.IncidentDescription = incidentVm.IncidentDescription;
            entityIncident.DailyUpdates = incidentVm.DailyUpdates;
            entityIncident.Category = incidentVm.Category;
            entityIncident.RootCauseAndRemarks = incidentVm.RootCauseAndRemarks;
            entityIncident.ResolutionCategory = incidentVm.ResolutionCategory;
            entityIncident.CurrentStatus = incidentVm.CurrentStatus;
            entityIncident.Severity = incidentVm.Severity;
            entityIncident.Priority = incidentVm.Priority;
            entityIncident.AlertType = incidentVm.AlertType;
            entityIncident.AssignedDate = incidentVm.AssignedDate;
            //entityIncident.as = incidentVm.Time;
            entityIncident.ApplicationName = incidentVm.ApplicationName;
            //entityIncident.ResponseTimeSLA_PHrs = InDetails.SLAResponseTime;
            // entityIncident.ResponseTimeSLA_PHrs = InDetails.SLAResponseTime;
            entityIncident.EffortInHours = incidentVm.EffortInHours;
            entityIncident.Track = incidentVm.Track;
            entityIncident.EffortInHours = incidentVm.EffortInHours;
            entityIncident.Owner = incidentVm.Owner;
            entityIncident.CreatedBy = cm.getUserName();
            return entityIncident;
        }


        public IncidentViewModel entityToVMMapping(EntityIncident entityIncident)
        {
            //EntityIncident InDetails = lstEntityIncident[0];
            IncidentViewModel incident = new IncidentViewModel();
            incident.Id = entityIncident.Id;
            incident.IncidentId = entityIncident.IncidentId;
            incident.IncidentDescription = entityIncident.IncidentDescription;
            incident.DailyUpdates = entityIncident.DailyUpdates;
            incident.Category = entityIncident.Category;
            incident.RootCauseAndRemarks = entityIncident.RootCauseAndRemarks;
            incident.ResolutionCategory = entityIncident.ResolutionCategory;
            incident.CurrentStatus = entityIncident.CurrentStatus;
            incident.Priority = entityIncident.Priority;
            incident.Severity = entityIncident.Severity;
            incident.ApplicationName = entityIncident.ApplicationName;
            incident.ResolutionSLA_PHrs = entityIncident.ResolutionSLA_PHrs;
            incident.EffortInHours = entityIncident.EffortInHours;
            incident.ResponseTimeSLA_PHrs = entityIncident.ResponseTimeSLA_PHrs;
            incident.Track = entityIncident.Track;
            incident.AlertType = entityIncident.AlertType;
            incident.AssignedDate = entityIncident.AssignedDate;
            return incident;
        }
        public List<IncidentViewModel> entityToVMMapping(List<Entity_Rpt_Incident> entityIncident)
        {
            List<IncidentViewModel> lstIncidentViewModel = new List<IncidentViewModel>();
            for (int i = 0; i < entityIncident.Count; i++)
            {
                IncidentViewModel incident = new IncidentViewModel();
                incident.Id = entityIncident[i].Id;
                incident.IncidentId = entityIncident[i].IncidentId;
                incident.IncidentDescription = entityIncident[i].IncidentDescription;
                incident.DailyUpdates = entityIncident[i].DailyUpdates;
                incident.Category = entityIncident[i].Category;
                incident.RootCauseAndRemarks = entityIncident[i].RootCauseAndRemarks;
                incident.ResolutionCategory = entityIncident[i].ResolutionCategory;
                incident.CurrentStatus = entityIncident[i].CurrentStatus;
                incident.Priority = entityIncident[i].Priority;
                incident.Severity = entityIncident[i].Severity;
                incident.ApplicationName = entityIncident[i].ApplicationName;
                incident.ResolutionSLA_PHrs = entityIncident[i].ResolutionSLA_PHrs;
                incident.EffortInHours = entityIncident[i].EffortInHours;
                incident.ResponseTimeSLA_PHrs = entityIncident[i].ResponseTimeSLA_PHrs;
                incident.Track = entityIncident[i].Track;
                incident.AlertType = entityIncident[i].AlertType;
                incident.SubCategory = entityIncident[i].SubCategory;
                incident.AssignedDate = entityIncident[i].AssignedDate.ToString().Trim().Substring(0,10);
                if(!string.IsNullOrEmpty(entityIncident[i].ResolvedDate))
                {
                    incident.ResolvedDate = entityIncident[i].ResolvedDate.ToString().Trim().Split(' ').ToList()[0];
                }
                lstIncidentViewModel.Add(incident);
            }
            return lstIncidentViewModel;
        }
    }
}