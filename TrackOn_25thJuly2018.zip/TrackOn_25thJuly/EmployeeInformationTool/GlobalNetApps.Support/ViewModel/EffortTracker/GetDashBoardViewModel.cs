﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;
using GlobalNetApps.Support.Common;
namespace GlobalNetApps.Support.Models
{
    public class GetDashBoardViewModel
    {
        [Required]
        public string AssignedFromDate { get; set; }
        [Required]
        public string AssignedToDate { get; set; }
        [Required]
        public string track { get; set; }
        [Required]
        [Range(1, 999999.99, ErrorMessage = "Please select a value")]
        public string Reports { get; set; }
        [Required]
        public int[] Type { get; set; }
        [Required]
        public int[] status { get; set; }
        public IEnumerable<SelectListItem> getDDlSelectListItem(List<EntityMasterTable> lstEMT)
        {
            List<SelectListItem> selectItems = new List<SelectListItem>();
            for (int i = 0; i < lstEMT.Count; i++)
            {               
                SelectListItem listItem = new SelectListItem();
                listItem.Value = lstEMT[i].id.ToString();
                listItem.Text = lstEMT[i].value.ToString();
                selectItems.Add(listItem);
            }
            return selectItems;
        }
        public EntityGetDashBoard getEntity(GetDashBoardViewModel dvm)
        {
            EntityGetDashBoard entity = new EntityGetDashBoard();
            entity.AssignedToDate = dvm.AssignedToDate;
            entity.AssignedFromDate = dvm.AssignedFromDate;
            entity.track = dvm.track;
            entity.ReportId = dvm.Reports;
            string status = string.Empty;
            string type = string.Empty;
            for (int i=0;i<dvm.status.Count();i++)
            {
                if(i == 0)
                {
                    status = dvm.status[i].ToString();

                }
                else
                {
                    status = status + "," + dvm.status[i].ToString();
                }              
            }
            for (int i = 0; i < dvm.Type.Count(); i++)
            {
                if (i == 0)
                {
                    type = dvm.Type[i].ToString();

                }
                else
                {
                    type = type + "," + dvm.Type[i].ToString();
                }

            }
            entity.status = status;
            entity.Type = type;
            return entity;
        }
    }
}