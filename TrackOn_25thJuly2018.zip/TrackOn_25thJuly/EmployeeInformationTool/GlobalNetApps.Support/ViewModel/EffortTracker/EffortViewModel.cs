﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;
using GlobalNetApps.Support.Common;
namespace GlobalNetApps.Support.Models
{
    public class EffortViewModel
    {
        CommonMethods cm = new CommonMethods();
        public int EffortId { get; set; }
        public string IncidentId { get; set; }
        public string IncidentDescription { get; set; }
        public string AssociateName { get; set; }
        public string EffortDate { get; set; }
        public string EffortSpentInHRs { get; set; }
        public string EffortType { get; set; }
        public int IsActive { get; set; }
        public EntityEffort vmToEntityMapping(EffortViewModel effortVm)
        {
            EntityEffort enty = new EntityEffort();
            enty.EffortId = Convert.ToInt32(effortVm.EffortId);
            enty.IncidentId = effortVm.IncidentId;
            enty.AssociateName = cm.getUserName();
            enty.EffortDate = effortVm.EffortDate;
            enty.EffortSpentInHRs = effortVm.EffortSpentInHRs;
            enty.EffortType = effortVm.EffortType;
            return enty;
        }
        public List<EffortViewModel> EntitytoVMMapping(List<EntityEffort> effortEntity)
        {
            List<EffortViewModel> lsteffortViewModel = new List<EffortViewModel>();
            for (int i = 0; i < effortEntity.Count; i++)
            {
                EffortViewModel effortViewModel = new EffortViewModel();
                effortViewModel.IncidentDescription = effortEntity[i].IncidentDescription;
                effortViewModel.EffortId = effortEntity[i].EffortId;
                effortViewModel.EffortDate = effortEntity[i].EffortDate;
                effortViewModel.EffortSpentInHRs = effortEntity[i].EffortSpentInHRs;
                effortViewModel.IncidentId = effortEntity[i].IncidentId;
                effortViewModel.AssociateName = effortEntity[i].AssociateName;
                effortViewModel.EffortType = effortEntity[i].EffortType;
                lsteffortViewModel.Add(effortViewModel);
            }
            return lsteffortViewModel;
        }
        public EffortViewModel EntitytoVMMapping(EntityEffort effortEntity)
        {
            EffortViewModel effortViewModel = new EffortViewModel();
            effortViewModel.IncidentDescription = effortEntity.IncidentDescription;
            effortViewModel.EffortId = effortEntity.EffortId;
            effortViewModel.EffortDate = effortEntity.EffortDate;
            effortViewModel.EffortSpentInHRs = effortEntity.EffortSpentInHRs;
            effortViewModel.IncidentId = effortEntity.IncidentId;
            effortViewModel.AssociateName = effortEntity.AssociateName;
            effortViewModel.EffortType = effortEntity.EffortType;
            return effortViewModel;
        }
    }


}