﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.Web.Mvc;
using GlobalNetApps.Support.Common;
using System.ComponentModel.DataAnnotations;

namespace GlobalNetApps.Support.Models
{
    public class UpdateIncidentViewModel
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(UpdateIncidentViewModel));
        CommonMethods cm = new CommonMethods();
        public int Id { get; set; }
        public string IncidentId { get; set; }
        public string DailyUpdates { get; set; }
        public string RootCause { get; set; }
        public string Resolution { get; set; }
        public string CurrentStatus { get; set; }
        public string CreatedBy { get; set; }
        public string ResolvedDate { get; set; }


        public UpdateIncidentViewModel getVm(EntityIncidentHistory entityIncidentHistory)
        {
            UpdateIncidentViewModel updateIncidentViewModel = new UpdateIncidentViewModel();
            updateIncidentViewModel.Id = entityIncidentHistory.Id;
            updateIncidentViewModel.IncidentId = entityIncidentHistory.IncidentId;
            updateIncidentViewModel.CurrentStatus = entityIncidentHistory.CurrentStatus;
            updateIncidentViewModel.DailyUpdates = entityIncidentHistory.DailyUpdates;
            return updateIncidentViewModel;
        }
        public EntityIncidentHistory getEntity(UpdateIncidentViewModel updateIncidentViewModel)
        {
            EntityIncidentHistory entityIncidentHistory = new EntityIncidentHistory();
            entityIncidentHistory.Id = updateIncidentViewModel.Id;
            entityIncidentHistory.IncidentId = updateIncidentViewModel.IncidentId;
            entityIncidentHistory.CurrentStatus = updateIncidentViewModel.CurrentStatus;
            entityIncidentHistory.DailyUpdates = updateIncidentViewModel.DailyUpdates;
            entityIncidentHistory.CreatedBy = cm.getUserName();
            if (updateIncidentViewModel.RootCause != null && updateIncidentViewModel.RootCause != "0")
            {
                entityIncidentHistory.RootCause = updateIncidentViewModel.RootCause;
                entityIncidentHistory.Resolution = updateIncidentViewModel.Resolution;
            }
            if (!string.IsNullOrEmpty(updateIncidentViewModel.ResolvedDate))
            {
                entityIncidentHistory.ResolvedDate = updateIncidentViewModel.ResolvedDate;
            }
            return entityIncidentHistory;
        }
        public List<SelectListItem> getDDlWithSelectedItem(List<EntityMasterTable> lstEMT, int id)
        {
            List<SelectListItem> selectItems = new List<SelectListItem>();
            try
            {
                var defualt = lstEMT.Where(x => x.id == id).SingleOrDefault();
                lstEMT.RemoveAll(x => x.id == id);
                SelectListItem defualtlistItem = new SelectListItem();
                defualtlistItem.Value = defualt.id.ToString();
                defualtlistItem.Text = defualt.value.ToString();
                selectItems.Add(defualtlistItem);
                for (int i = 0; i < lstEMT.Count; i++)
                {
                    SelectListItem listItem = new SelectListItem();
                    listItem.Value = lstEMT[i].id.ToString();
                    listItem.Text = lstEMT[i].value.ToString();
                    selectItems.Add(listItem);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);               
            }
            return selectItems;
        }
    }
}