﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.Services.Entites;
namespace GlobalNetApps.Support.Models
{
    public class IdentityServiceViewModel
    {
        public string UserName { get; set; }
        public string EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AccountExpiry { get; set; }
        public string LastLogon { get; set; }
        public string PasswordExpiry { get; set; }
        public string EmailAddress { get; set; }
        public List<string> groups { get; set; }     
        public IdentityServiceViewModel Create(IdentityService_EmpInfo isInfo)
        {
            IdentityServiceViewModel service_data = new IdentityServiceViewModel();
            service_data.AccountExpiry = isInfo.AccountExpiry.ToString();
            service_data.LastLogon = isInfo.LastLogon;
            service_data.PasswordExpiry = isInfo.PasswordExpiry;
            service_data.EmailAddress = isInfo.EmailAddress;
            service_data.FirstName = isInfo.FirstName;
            service_data.LastName = isInfo.LastName;
            service_data.UserName = isInfo.UserName;
            service_data.EmployeeId = isInfo.EmpId;
            service_data.groups = isInfo.groups;
            return service_data;
        }
    }

  
}