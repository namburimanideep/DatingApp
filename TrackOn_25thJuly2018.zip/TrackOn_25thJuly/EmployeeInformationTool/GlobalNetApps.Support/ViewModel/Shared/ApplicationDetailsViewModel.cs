﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.Web.Mvc;

namespace GlobalNetApps.Support.Models
{
    public class ApplicationDetailsViewModel
    {
        public int Tier { get; set; }
        public string application { get; set; }
        public string complexity { get; set; }
        public string AppCode { get; set; }
        public string Track { get; set; }
        public string Groups { get; set; }

        public List<ApplicationDetailsViewModel> getAppDetails(List<EntityApplications> lstEntityAppDetails)
        {
            List<ApplicationDetailsViewModel> lstAppVM = new List<ApplicationDetailsViewModel>();
            for (int i = 0; i < lstEntityAppDetails.Count; i++)
            {
                ApplicationDetailsViewModel appVm = new ApplicationDetailsViewModel();
                appVm.Tier = lstEntityAppDetails[i].Tier;
                appVm.application = lstEntityAppDetails[i].application;
                appVm.complexity = lstEntityAppDetails[i].complexity;
                appVm.AppCode = lstEntityAppDetails[i].AppCode;
                appVm.Track = lstEntityAppDetails[i].Track;
                appVm.Groups = lstEntityAppDetails[i].Groups;
                lstAppVM.Add(appVm);
            }
            return lstAppVM;
        }
    }
}