﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GlobalNetApps.Support.Models
{
    public class dropDownViewModel
    {
        public string data { get; set; }
        public List<dropDownViewModel> createDDL(List<string> ddlData)
        {
            List<dropDownViewModel> lstDDL = new List<dropDownViewModel>();
            for (int i = 0; i < ddlData.Count; i++)
            {
                dropDownViewModel ddl = new dropDownViewModel();
                ddl.data = ddlData[i];
                lstDDL.Add(ddl);
            }
            return lstDDL;
        }
        public List<dropDownViewModel> createDDLhours()
        {
            List<dropDownViewModel> lstDDL = new List<dropDownViewModel>();
            for (int i = 1; i < 25; i++)
            {
                dropDownViewModel ddl = new dropDownViewModel();
                ddl.data = i.ToString();
                lstDDL.Add(ddl);
            }
            return lstDDL;
        }
    }
}