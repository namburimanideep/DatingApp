﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using System.ComponentModel.DataAnnotations;

namespace GlobalNetApps.Support.Models
{
    public class AssociatesViewModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string EmailId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastUpdatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public DateTime LastUpdatedDateTime { get; set; }
        public int IsActive { get; set; }

        public List<AssociatesViewModel> getAssociates(List<EntityAssociates> entityAssociates)
        {
            List<AssociatesViewModel> lstAssociatesViewModel = new List<AssociatesViewModel>();
            for (int i = 0; i < entityAssociates.Count; i++)
            {
                AssociatesViewModel associatesViewModel = new AssociatesViewModel();
                associatesViewModel.ID = entityAssociates[i].ID;
                associatesViewModel.Name = entityAssociates[i].Name;
                associatesViewModel.UserName = entityAssociates[i].UserName;
                associatesViewModel.EmailId = entityAssociates[i].EmailId;
                associatesViewModel.CreatedBy = entityAssociates[i].CreatedBy;
                associatesViewModel.LastUpdatedBy = entityAssociates[i].LastUpdatedBy;
                associatesViewModel.CreatedDateTime = entityAssociates[i].CreatedDateTime;
                associatesViewModel.LastUpdatedDateTime = entityAssociates[i].LastUpdatedDateTime;
                associatesViewModel.IsActive = entityAssociates[i].IsActive;
                lstAssociatesViewModel.Add(associatesViewModel);
            }
            return lstAssociatesViewModel;
        }
        public EntityAssociates getAssociatesEntity(AssociatesViewModel associatesViewModel)
        {
            EntityAssociates entityAssociates = new EntityAssociates();
            entityAssociates.ID = associatesViewModel.ID;
            entityAssociates.Name = associatesViewModel.Name;
            entityAssociates.UserName = associatesViewModel.UserName;
            entityAssociates.EmailId = associatesViewModel.EmailId;
            entityAssociates.CreatedBy = associatesViewModel.CreatedBy;
            entityAssociates.LastUpdatedBy = associatesViewModel.LastUpdatedBy;
            entityAssociates.CreatedDateTime = associatesViewModel.CreatedDateTime;
            entityAssociates.LastUpdatedDateTime = associatesViewModel.LastUpdatedDateTime;
            entityAssociates.IsActive = associatesViewModel.IsActive;
            return entityAssociates;
        }
    }
}