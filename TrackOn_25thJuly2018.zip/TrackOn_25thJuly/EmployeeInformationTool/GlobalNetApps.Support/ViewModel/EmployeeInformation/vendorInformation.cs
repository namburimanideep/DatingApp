﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;

namespace GlobalNetApps.Support.Models
{
    public class vendorInformation
    {
        public List<vendorAD> lstVendorAD { get; set; }
        public List<vendorEI> lstVendorEI { get; set; }
        public List<vendorCC> lstVendorCC { get; set; }

        public List<vendorAD> vendorMapping_AD(List<EntityVendorADDorMove> AD_veninfo)
        {
            List<vendorAD> lstVendorAD = new List<vendorAD>();
            foreach (var vendorinfo in AD_veninfo)
            {
                vendorAD vAD = new vendorAD();
                vAD.TableName = vendorinfo.TableName;
                vAD.NewUserName = vendorinfo.NewUserName;
                vAD.OldUserName = vendorinfo.OldUserName;
                vAD.NewEmployeeId = vendorinfo.NewEmployeeId;
                vAD.OldEmployeeId = vendorinfo.OldEmployeeId;
                vAD.NewFullName = vendorinfo.NewFullName;
                vAD.OldFullName = vendorinfo.OldFullName;
                vAD.NewEmployeeEmail = vendorinfo.NewEmployeeEmail;
                vAD.oldEmployeeEmail = vendorinfo.oldEmployeeEmail;
                vAD.OldEmployeeStatus = vendorinfo.OldEmployeeStatus;
                vAD.NewEmployeeStatus = vendorinfo.NewEmployeeStatus;
                vAD.NewEmployeeDOH = vendorinfo.NewEmployeeDOH;
                vAD.oldEmployeeDOH = vendorinfo.oldEmployeeDOH;
                lstVendorAD.Add(vAD);
            }
            return lstVendorAD;
        }
        public List<vendorEI> vendorMapping_EI(List<EntityVendorADDorMove> EI_veninfo)
        {
            List<vendorEI> lstVendorEI = new List<vendorEI>();
            foreach (var vendorinfo in EI_veninfo)
            {
                vendorEI vEI = new vendorEI();
                vEI.TableName = vendorinfo.TableName;
                vEI.NewUserName = vendorinfo.NewUserName;
                vEI.OldUserName = vendorinfo.OldUserName;
                vEI.NewEmployeeId = vendorinfo.NewEmployeeId;
                vEI.OldEmployeeId = vendorinfo.OldEmployeeId;
                vEI.NewFullName = vendorinfo.NewFullName;
                vEI.OldFullName = vendorinfo.OldFullName;
                vEI.NewEmployeeEmail = vendorinfo.NewEmployeeEmail;
                vEI.oldEmployeeEmail = vendorinfo.oldEmployeeEmail;
                vEI.OldEmployeeStatus = vendorinfo.OldEmployeeStatus;
                vEI.NewEmployeeStatus = vendorinfo.NewEmployeeStatus;
                vEI.NewEmployeeDOH = vendorinfo.NewEmployeeDOH;
                vEI.oldEmployeeDOH = vendorinfo.oldEmployeeDOH;
                lstVendorEI.Add(vEI);
            }
            return lstVendorEI;
        }

        public List<vendorCC> vendorMapping_CC(List<EntityVendorADDorMove> CC_veninfo)
        {
            List<vendorCC> lstVendorCC = new List<vendorCC>();
            foreach (var vendorinfo in CC_veninfo)
            {
                vendorCC vCC = new vendorCC();
                vCC.TableName = vendorinfo.TableName;
                vCC.SequenceNumber = vendorinfo.SequenceNumber;
                vCC.TERNumber = vendorinfo.TERNumber;
                vCC.cccMonthlyid = vendorinfo.cccMonthlyid;
                vCC.Cm_Name = vendorinfo.Cm_Name;
                vCC.NewEmployeeId = vendorinfo.NewEmployeeId;
                lstVendorCC.Add(vCC);

            }
            return lstVendorCC;
        }

        public vendorInformation createVendorInfo( List<EntityVendorADDorMove> venInfo)
        {
            List<EntityVendorADDorMove> AD_veninfo = venInfo.Where(X => X.TableName == "AD").ToList();
            List<EntityVendorADDorMove> EI_veninfo = venInfo.Where(X => X.TableName == "EI").ToList();
            List<EntityVendorADDorMove> CC_veninfo = venInfo.Where(X => X.TableName == "CC").ToList();
            vendorInformation venInfoVm = new vendorInformation();
            venInfoVm.lstVendorEI = vendorMapping_EI(EI_veninfo);
            venInfoVm.lstVendorAD = vendorMapping_AD(AD_veninfo);
            venInfoVm.lstVendorCC = vendorMapping_CC(CC_veninfo);       
            return venInfoVm;
        }
        public class vendorAD
        {
            public string TableName { get; set; }
            public string NewUserName { get; set; }
            public string OldUserName { get; set; }
            public string NewEmployeeId { get; set; }
            public string OldEmployeeId { get; set; }
            public string NewFullName { get; set; }
            public string OldFullName { get; set; }
            public string NewEmployeeStatus { get; set; }
            public string OldEmployeeStatus { get; set; }
            public string NewEmployeeDOH { get; set; }
            public string oldEmployeeDOH { get; set; }
            public string NewEmployeeEmail { get; set; }
            public string oldEmployeeEmail { get; set; }

        }
        public class vendorEI
        {
            public string TableName { get; set; }
            public string NewUserName { get; set; }
            public string OldUserName { get; set; }
            public string NewEmployeeId { get; set; }
            public string OldEmployeeId { get; set; }
            public string NewFullName { get; set; }
            public string OldFullName { get; set; }
            public string NewEmployeeStatus { get; set; }
            public string OldEmployeeStatus { get; set; }
            public string NewEmployeeDOH { get; set; }
            public string oldEmployeeDOH { get; set; }
            public string NewEmployeeEmail { get; set; }
            public string oldEmployeeEmail { get; set; }

        }
        public class vendorCC
        {
            public string TableName { get; set; }
            public string SequenceNumber { get; set; }
            public string TERNumber { get; set; }
            public string Cm_Name { get; set; }
            public string cccMonthlyid { get; set; }
            public string NewEmployeeId { get; set; }
        }
    }
}