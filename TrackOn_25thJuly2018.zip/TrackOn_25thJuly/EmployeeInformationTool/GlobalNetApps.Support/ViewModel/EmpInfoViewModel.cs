﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;
namespace GlobalNetApps.Support.Models
{
    public class EmpInfoViewModel
    {
        public List<EI_EmpInfoViewModel> Emp_EI { get; set; }
        public List<AD_EmpInfoViewModel> Emp_AD { get; set; }
        public List<CorpCardInfoViewModel> Emp_CC { get; set; }
        public List<TomsViewModel> Emp_Toms { get; set; }
        public EmpInfoViewModel createEntityEmployeeInfo(List<EntityEmployeeInfo> empinfo, List<CorpCardInfoViewModel> ccInfo, List<TomsViewModel> lsttoms)
        {
            List<EntityEmployeeInfo> AD_empinfo = empinfo.Where(X => X.TableName == "AD").ToList();
            List<EntityEmployeeInfo> EI_empinfo = empinfo.Where(X => X.TableName == "EI").ToList();            
            EmpInfoViewModel empinfovm = new EmpInfoViewModel();
            empinfovm.Emp_EI = mapping_EI(EI_empinfo);
            empinfovm.Emp_AD = mapping_AD(AD_empinfo);
            empinfovm.Emp_CC = ccInfo;
            empinfovm.Emp_Toms = lsttoms;       
            return empinfovm;
        }
        public List< EI_EmpInfoViewModel> mapping_EI(List<EntityEmployeeInfo> lstempinfo)
        {
            List<EI_EmpInfoViewModel> lstempinfovm = new List<EI_EmpInfoViewModel>();            
            foreach (var empinfo in lstempinfo)
            {
                EI_EmpInfoViewModel empinfovm = new EI_EmpInfoViewModel();
                empinfovm.TableName = empinfo.TableName;
                empinfovm.UserName = empinfo.UserName;
                empinfovm.mail = empinfo.mail;
                empinfovm.EmployeeId = empinfo.EmployeeId;
                empinfovm.EmployeeStatus = empinfo.EmployeeStatus;
                empinfovm.EmployeeType = empinfo.EmployeeType;
                empinfovm.BusinessUnit = empinfo.BusinessUnit;
                empinfovm.Company = empinfo.Company;
                empinfovm.HiringDate = empinfo.HiringDate;
                empinfovm.ResigningDate = empinfo.ResigningDate;
                empinfovm.FullName = empinfo.FullName;
                lstempinfovm.Add(empinfovm);
            }
            return lstempinfovm;
        }
        public List<AD_EmpInfoViewModel> mapping_AD(List<EntityEmployeeInfo> lstempinfo)
        {
            List<AD_EmpInfoViewModel> lstempinfovm = new List<AD_EmpInfoViewModel>();           
            foreach (var empinfo in lstempinfo)
            {
                AD_EmpInfoViewModel empinfovm = new AD_EmpInfoViewModel();
                empinfovm.TableName = empinfo.TableName;
                empinfovm.UserName = empinfo.UserName;
                empinfovm.mail = empinfo.mail;
                empinfovm.EmployeeId = empinfo.EmployeeId;
                empinfovm.EmployeeStatus = empinfo.EmployeeStatus;
                empinfovm.EmployeeType = empinfo.EmployeeType;
                empinfovm.BusinessUnit = empinfo.BusinessUnit;
                empinfovm.Company = empinfo.Company;
                empinfovm.HiringDate = empinfo.HiringDate;
                empinfovm.ResigningDate = empinfo.ResigningDate;
                empinfovm.FullName = empinfo.FullName;
                lstempinfovm.Add(empinfovm);
            }
            return lstempinfovm;
        }
    }
}