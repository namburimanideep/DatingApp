﻿namespace GlobalNetApps.Support.Controllers
{   
    using System.Configuration;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;
    using System.Web.Security;
    /// <summary>
    /// Custom Authorization implemented using Authorize Attribute
    /// </summary>
    public class BaseAuthorizeAttribute : AuthorizeAttribute
    {
        public BaseAuthorizeAttribute()
        {
        }
        public BaseAuthorizeAttribute(string App)
        {
            switch (App)
            {
                case "Admin":
                    Roles = ConfigurationManager.AppSettings.Get("Admin");
                    break;
                case "DotNet":
                    Roles = ConfigurationManager.AppSettings.Get("DotNet");
                    break;
                case "IncidentManagement":
                    Roles = ConfigurationManager.AppSettings.Get("IncidentManagement");
                    break;
                default:
                    break;
            }
        }
        /// <summary>
        /// This method will call while authorizing the controller or action level events
        /// </summary>
        /// <param name="filterContext">filterContext</param>
        ///
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            //Read cookies name from request object
            var authCookie = System.Web.HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                //Decrypt the cookies detaisl for to find out the user data
                FormsAuthenticationTicket authTicket = FormsAuthentication.Decrypt(authCookie.Value);
                if (authTicket != null && !authTicket.Expired)
                {
                    var usergroups = authTicket.UserData.Split(',');
                    HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(new FormsIdentity(authTicket), usergroups);
                    foreach (var group in Roles.Split(','))
                    {
                        //Valid user roles 
                        if (HttpContext.Current.User.IsInRole(group))
                        {
                            base.OnAuthorization(filterContext);
                            return;
                        }
                        filterContext.Result = new RedirectToRouteResult(
                      new RouteValueDictionary(new { Controller = "Error", Action = "AccessDenied" }));
                    }
                }
                else
                {
                    //Return to login page if user session expired.
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { Controller = "Account", Action = "login" }));
                }
            }
            else
            {
                //Return to login page if user cookie expired.
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { Controller = "Account", Action = "login" }));
            }
        }
    }
}