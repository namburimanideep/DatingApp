﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;

namespace GlobalNetApps.Support.Services.Interfaces
{
    interface IServiceEmployeeInfo
    {
        List<EntityEmployeeInfo> GetInfo(EntityGetEmpInfo getinfo);
        IdentityService_EmpInfo getProfile(string username);
    }
}
