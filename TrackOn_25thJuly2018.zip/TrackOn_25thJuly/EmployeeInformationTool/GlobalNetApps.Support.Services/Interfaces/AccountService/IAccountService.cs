﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace GlobalNetApps.Support.Services.Interfaces
{
  public  interface IAccountService
    {
        string validateLogin(string username, string password);
    }
}
