﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;

namespace GlobalNetApps.Support.Services.Interfaces
{
    public interface IApplicationService
    {
        List<EntityApplications> getApplicationDetails();
    }
}
