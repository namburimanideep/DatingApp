﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.Services.Entites
{
    public class IdentityService_EmpInfo
    {
        public string EmpId { get; set; }
        public string FirstName { get; set; }
        public string UserName { get; set; }
        public string LastName { get; set; }
        public string AccountExpiry { get; set; }
        public string LastLogon { get; set; }
        public string PasswordExpiry { get; set; }
        public string EmailAddress { get; set; }
        public List<string> groups { get; set; }
    }
}
