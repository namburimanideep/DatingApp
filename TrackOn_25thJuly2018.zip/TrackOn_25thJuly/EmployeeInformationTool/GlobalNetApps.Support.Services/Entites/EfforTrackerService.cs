﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalNetApps.Support.Services.Interfaces;
using GlobalNetApps.Support.DAL.Repositories;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.Services.EmployeeInformationService;
using System.Globalization;

namespace GlobalNetApps.Support.Services.Repositories
{
    public class EfforTrackerService : IEffortTrackerService
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(ServiceEmployeeInfo));
        EffortTrackerRepository effortTrackerRepository = new EffortTrackerRepository();
        public List<string> getStatus()
        {
            return effortTrackerRepository.getStatus();
        }
        public List<string> getPriority()
        {
            return effortTrackerRepository.getPriority();
        }
        public List<string> getApplication()
        {
            return effortTrackerRepository.getApplication();
        }
        public List<string> getName()
        {
            return effortTrackerRepository.getName();
        }
        public List<string> getTracks()
        {
            return effortTrackerRepository.getTracks();
        }
        public List<string> getTypeOfIncident()
        {
            return effortTrackerRepository.getTypeOfIncident();
        }
        public List<string> getRootCause()
        {
            return effortTrackerRepository.getRootCause();
        }

    }
}
