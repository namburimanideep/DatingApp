﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalNetApps.Support.Services.Interfaces;
using GlobalNetApps.Support.DAL.Repositories;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.Services.EmployeeInformationService;
namespace GlobalNetApps.Support.Services.Repositories
{
    public class ServiceEmployeeInfo : IServiceEmployeeInfo
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(ServiceEmployeeInfo));
        public IdentityService_EmpInfo getProfile(string username)
        {
            IdentityService Iservice = new IdentityService();
            IdentityService_EmpInfo identityService = new IdentityService_EmpInfo();
            try
            {
                var profile = Iservice.GetUserProfile(username);
                if (profile != null)
                {
                    identityService.EmpId = Iservice.GetAttribute(username, "employeeid");
                    identityService.UserName = profile.Username;
                    identityService.EmailAddress = profile.EmailAddress;
                    identityService.FirstName = profile.FirstName;
                    identityService.LastName = profile.LastName;
                    identityService.LastLogon = profile.LastLogon.ToString();
                    identityService.AccountExpiry = profile.AccountExpiry.ToString();
                    identityService.PasswordExpiry = profile.PasswordExpiry.ToString();
                    var groups = (profile.Groups.memberOf);
                    List<string> groupList = new List<string>();
                    for (int i = 0; i < groups.Count(); i++)
                    {
                        int k = groups[i].sAMAccountName.ToString().IndexOf(",");
                        string c1 = groups[i].sAMAccountName.ToString();
                        string c = groups[i].sAMAccountName.ToString().Substring(0, groups[i].sAMAccountName.ToString().IndexOf(","));
                        groupList.Add(c.Replace("CN=", ""));
                    }
                    identityService.groups = groupList;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return identityService;
              
            }
            return identityService;
        }
        public List<EntityApplications> getApplicationDetails()
        {
            try
            {
                ApplicationRepository<EntityApplications> app = null;
                app = new ApplicationRepository<EntityApplications>();
                return app.getApplicationDetails();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
        public List<EntityEmployeeInfo> GetInfo(EntityGetEmpInfo getinfo)
        {
            try
            {

                EmployeeInfoRepository<EntityGetEmpInfo> emp = null;
                emp = new EmployeeInfoRepository<EntityGetEmpInfo>();
                return emp.GetEmployeeInfo(getinfo);
            }
            catch (Exception ex)
            {
              Log.Error(ex.Message);
               throw (ex);
            }
        }
        public List<EntityCorpCardInfo> GetCCInfo(string Condition)
        {
            try
            {
                CorpCardChargesRepository<EntityCorpCardInfo> emp = null;
                emp = new CorpCardChargesRepository<EntityCorpCardInfo>();
                return emp.GetCCInfo(Condition);
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public List<EntityCorpCardInfo> GetSingleTERInfo(string Condition)
        {
            try
            {
                CorpCardChargesRepository<EntityCorpCardInfo> emp = null;
                emp = new CorpCardChargesRepository<EntityCorpCardInfo>();
                return emp.GetSingleTERInfo(Condition);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
        public List<EntityTomsInfo> GetTomsInfo(String tomsEmpIDByComma)
        {
            try
            {
                TomsInfoRepository<EntityTomsInfo> emp = null;
                emp = new TomsInfoRepository<EntityTomsInfo>();
                return emp.GetTomsInfo(tomsEmpIDByComma);
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public List<EntityGetCCCMonthlyId> updatCorpCardWithNewEmpid(string newEmpid, string oldEmpid,string query)
        {
            try
            {

                CorpCardChargesRepository_dev<EntityGetCCCMonthlyId> CCCmonthlyId = null;
                CCCmonthlyId = new CorpCardChargesRepository_dev<EntityGetCCCMonthlyId>();
                return CCCmonthlyId.GetCCCMonthly_ID(newEmpid, oldEmpid, query);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
        public List<EntityVendorADDorMove> GetVendorInfo(String newID, string query)
        {
            try
            {
                EmployeeInfoRepository<EntityTomsInfo> emp = null;
                emp = new EmployeeInfoRepository<EntityTomsInfo>();
                return emp.GetVendorInfo(newID, query);
            }
            catch (Exception ex)
            {
              Log.Error(ex.Message);
               throw (ex);
            }
        }
    }
}
