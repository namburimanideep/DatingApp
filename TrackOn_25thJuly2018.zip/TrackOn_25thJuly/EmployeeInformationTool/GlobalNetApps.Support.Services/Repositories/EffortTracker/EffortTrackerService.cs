﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalNetApps.Support.Services.Interfaces;
using GlobalNetApps.Support.DAL.Repositories;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.Services.EmployeeInformationService;
using System.Globalization;
using System.Data;

namespace GlobalNetApps.Support.Services.Repositories
{
    public class EffortTrackerService : IEffortTrackerService
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(ServiceEmployeeInfo));
        EffortTrackerDataRepository<EntityMasterTable> effortTrackerRepository = new EffortTrackerDataRepository<EntityMasterTable>();
        public List<EntityMasterTable> getStatus()
        {
            return effortTrackerRepository.getStatus();
        }
        public List<EntityMasterTable> getAlertType()
        {
            return effortTrackerRepository.getAlertType();
        }
        public List<EntityMasterTable> getPriority()
        {
            return effortTrackerRepository.getPriority();
        }
        public List<EntityMasterTable> getApplication(string userName)
        {
            return effortTrackerRepository.getApplication(userName);
        }
        public List<EntityMasterTable> getName(string userName)
        {
            return effortTrackerRepository.getName(userName);
        }
        public List<EntityMasterTable> getRoles(string userName)
        {
            return effortTrackerRepository.getRoles(userName);
        }
        public List<EntityMasterTable> getTracks()
        {
            return effortTrackerRepository.getTracks();
        }
        public List<EntityMasterTable> getTrackId(string userName)
        {
            return effortTrackerRepository.getTrackId(userName);
        }
        public List<EntityMasterTable> getReports()
        {
            return effortTrackerRepository.getReports();
        }
        public List<EntityMasterTable> getSeverity()
        {
            return effortTrackerRepository.getSeverity();
        }
        public List<EntityMasterTable> getTypeOfIncident(string userName)
        {
            return effortTrackerRepository.getTypeOfIncident(userName);
        }
        public List<EntityMasterTable> getRootCause(string userName)
        {
            return effortTrackerRepository.getRootCause(userName);
        }
        public List<EntityMasterTable> getResolution(string userName)
        {
            return effortTrackerRepository.getResolution(userName);
        }
        public List<EntityMasterTable> getIncidentDropDown(string userName)
        {
            return effortTrackerRepository.getIncidentDropDown(userName);
        }
        public List<EntityMasterTable> getEffortType(string userName)
        {
            return effortTrackerRepository.getEffortType(userName);
        }
        public List<EntityMasterTable> getTypeOfIncident(int trackId)
        {
            return effortTrackerRepository.getTypeOfIncident(trackId);
        }
        #region Incidents
        public List<Entity_Rpt_Incident> getEntireTrackData(string userName, int getAllData)
        {
            return effortTrackerRepository.getEntireTrackData(userName, getAllData);
        }
        public List<EntityIncident> getIncidents(string username)
        {
            return effortTrackerRepository.getIncidents(username);
        }
        public List<EntityMasterTable> getOpenIncidentForTrack(string UserName)
        {
            return effortTrackerRepository.getOpenIncidentForTrack(UserName);
        }
        public List<EntityIncidentHistory> getHistory(int incidentId)
        {
            return effortTrackerRepository.getHistory(incidentId);
        }
        public int addIncident(EntityIncident adIncident)
        {
            int result = effortTrackerRepository.addIncident(adIncident);
            return result;

        }
        public int UpdateIncident(EntityIncidentHistory entityIncidentHistory)
        {
            return effortTrackerRepository.UpdateIncident(entityIncidentHistory);
        }
        public List<EntitySLA> GetDetailsForSLA(string username)
        {
            return effortTrackerRepository.GetDetailsForSLA(username);
        }

        public int UpdateSLATimings(List<EntitySLA> lstSLA)
        {
            int result = effortTrackerRepository.UpdateSLATimings(lstSLA);
            return result;
        }
        #endregion

        #region Effort
        public List<EntityEffort> getEfforts(string username)
        {
            return effortTrackerRepository.getEfforts(username);
        }
        public EntityEffort addEffort(EntityEffort addEffort)
        {
            return effortTrackerRepository.addEfforts(addEffort);
        }
        public int updateEffort(EntityEffort entityEffort)
        {
            return effortTrackerRepository.updateEffort(entityEffort);
        }
        public int deleteEffort(int effortId)
        {
            return effortTrackerRepository.deleteEffort(effortId);
        }
        #endregion

        #region Reports
        public List<Entity_Rpt_Incident> getDashBoard(EntityGetDashBoard entityDashBoard)
        {
            return effortTrackerRepository.getDashBoard(entityDashBoard);
        }
        public List<Entity_Rpt_GetDashBoardByGrouping> getReport(EntityGetDashBoard entityDashBoard)
        {
            return effortTrackerRepository.getReport(entityDashBoard);
        }
        #endregion
    }
}
