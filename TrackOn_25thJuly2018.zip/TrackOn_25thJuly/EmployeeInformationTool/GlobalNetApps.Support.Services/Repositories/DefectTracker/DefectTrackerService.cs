﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalNetApps.Support.Services.Interfaces;
using GlobalNetApps.Support.DAL.Repositories;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.Services.EmployeeInformationService;
using System.Globalization;
using System.Data;

namespace GlobalNetApps.Support.Services.Repositories
{
    public class DefectTrackerService
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(DefectTrackerService));
        DefectTrackerRepository<EntityDefects> defectTrackerRepository = new DefectTrackerRepository<EntityDefects>();

        public List<EntityDefects> getDefects()
        {
            return defectTrackerRepository.getDefects();
        }
        public List<EntityDefects> UploadDefects(EntityDefects defects)
        {
            return defectTrackerRepository.UploadDefects(defects);
        }
    }
}
