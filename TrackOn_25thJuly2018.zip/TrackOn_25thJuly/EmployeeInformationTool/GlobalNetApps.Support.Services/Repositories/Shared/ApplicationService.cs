﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalNetApps.Support.Services.Interfaces;
using GlobalNetApps.Support.DAL.Repositories;
using GlobalNetApps.Support.DAL.Entites;
using GlobalNetApps.Support.Services.Entites;
using GlobalNetApps.Support.Services.EmployeeInformationService;
using System.Globalization;

namespace GlobalNetApps.Support.Services.Repositories
{
    public class ApplicationService : IApplicationService
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(ServiceEmployeeInfo));
        ApplicationRepository<EntityApplications> applicationRepository = new ApplicationRepository<EntityApplications>();

        public List<EntityApplications> getApplicationDetails()
        {
            try
            {

                return applicationRepository.getApplicationDetails();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
    }
   
}
