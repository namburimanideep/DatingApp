﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.Services.Interfaces;
using GlobalNetApps.Support.DAL.Repositories;
using GlobalNetApps.Support.DAL.Entites;

namespace GlobalNetApps.Support.Services.Repositories
{
    public class MasterDataService : IMasterDataService
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(ServiceEmployeeInfo));

        MasterDataRepository<EntityAssociates> associatesRepository = new MasterDataRepository<EntityAssociates>();

        public List<EntityAssociates> GetAssociates()
        {
            return associatesRepository.GetAssociates();
        }
        public int AddAssociates(EntityAssociates entityAssociate)
        {
            return associatesRepository.AddAssociates(entityAssociate);
        }
        public int UpdateAssociates(EntityAssociates entityAssociate)
        {
            return associatesRepository.UpdateAssociates(entityAssociate);
        }
        public int DeleteAssociates(int Id)
        {
            return associatesRepository.DeleteAssociates(Id);
        }
    }
}
