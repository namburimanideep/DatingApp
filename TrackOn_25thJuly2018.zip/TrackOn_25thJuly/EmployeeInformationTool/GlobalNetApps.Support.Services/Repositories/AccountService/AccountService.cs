﻿using System;
using GlobalNetApps.Support.Services.Interfaces;
using GlobalNetApps.Support.Services.EmployeeInformationService;
namespace GlobalNetApps.Support.Services.Repositories
{
   public class AccountService :IAccountService
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(AccountService));
        public string validateLogin(string username, string password)
        {
            int valid = 0;
            string serviceUsername = string.Empty; ;
            // Call Authentication web serivces to check username and password is valid or not
            string grouplist = string.Empty;
            try
            {
                IdentityService adAuth = new IdentityService();
                if (adAuth.Authenticate(username, password) == 1)
                {
                    serviceUsername = adAuth.GetAttribute(username,"name");
                    valid = 1;
                }
                else
                {
                    valid = 0;
                }
            }
            catch (Exception ex)
            {
                valid = 0;
                Log.Error(ex.Message); 
                throw(ex);
            }
            return serviceUsername;           
        }
    }
}
