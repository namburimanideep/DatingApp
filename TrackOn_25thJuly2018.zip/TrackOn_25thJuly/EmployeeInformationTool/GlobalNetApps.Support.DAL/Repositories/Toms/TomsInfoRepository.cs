﻿

namespace GlobalNetApps.Support.DAL.Repositories
{
     using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Configuration;
    using GlobalNetApps.Support.DAL.Interfaces;
    using GlobalNetApps.Support.DAL.Entites;
    using Dapper;
    public class TomsInfoRepository<T> : BaseRepository<T>, ITomsInfo
    {
        public TomsInfoRepository()
            : base(ConfigurationManager.ConnectionStrings["Toms"].ConnectionString)
        {
        }
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(TomsInfoRepository<T>));
        public List<EntityTomsInfo> GetTomsInfo(string tomsEmpIDByComma)
        {
            try
            {
                TomsInfoRepository<EntityTomsInfo> repoTomsData = null;
                repoTomsData = new TomsInfoRepository<EntityTomsInfo>();
                List<EntityTomsInfo> lstTomsInfo = new List<EntityTomsInfo>();
                try
                {
                    var parameters = new DynamicParameters();
                    string querySelecet = "SELECT TOP 1000 [EmployeeID],[UserName],[LastName],[FirstName],[EmployeePositionID],[SupervisorPositionID],[VPPositionID],[Location],[HireDate],[TerminationDate],[CompanyCode],[DateTimeUploaded],[EmployeeType]  FROM [TimeTracker_10152013].[dbo].[EmployeeInformation]";
                    lstTomsInfo = repoTomsData.Executequery(querySelecet + tomsEmpIDByComma).ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
                return lstTomsInfo;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
    }
  
}
