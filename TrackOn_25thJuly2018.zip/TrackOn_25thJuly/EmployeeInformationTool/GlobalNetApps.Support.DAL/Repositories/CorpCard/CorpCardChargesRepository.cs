﻿namespace GlobalNetApps.Support.DAL.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Configuration;
    using GlobalNetApps.Support.DAL.Interfaces;
    using GlobalNetApps.Support.DAL.Entites;
    using Dapper;
    public class CorpCardChargesRepository<T> : BaseRepository<T>, ICorpCardCharges
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(CorpCardChargesRepository<T>));
        public CorpCardChargesRepository()
            : base(ConfigurationManager.ConnectionStrings["CorpCardProd"].ConnectionString)
        {

        }
        public List<EntityCorpCardInfo> GetCCInfo(string queryWhere)
        {
            try
            {
                CorpCardChargesRepository<EntityCorpCardInfo> repoCorpCardCharges = null;
                repoCorpCardCharges = new CorpCardChargesRepository<EntityCorpCardInfo>();
                List<EntityCorpCardInfo> lstCCEmployeeInfo = new List<EntityCorpCardInfo>();
                try
                {
                    var parameters = new DynamicParameters();
                    string querySelecet = "SELECT [TER_Num],[cm_name],[emp_id],[Seq_num],[bill_acct_num],[charge_dt],[insert_date] ,[billdate],[insert_dt],[amount],[localamount],[description],Case when [Status] = 1 THEN 'Unsubmitted' when[Status] = 2 THEN 'Submitted' when[Status] = 3 THEN 'Not Compliant' when[Status] = 4 THEN 'Approved' when[Status] = 5 THEN 'Saved' when[Status] = 6 THEN 'Trip Cancelled / Pattern Changed' when[Status] = 7 THEN 'Personal Charge' when[Status] = 8 THEN 'Other' when[Status] = 9 THEN 'Submitted - Not Processed' when[Status] = 10 THEN 'Denied' when[Status] = 11 THEN 'Okay To Pay' when[Status] = 12 THEN 'Approved & Audited' END as [Status],[CCCMonthly_ID],[update_date],[managername] ,[manageremail],[cardtype],[businesspurposes],[emp_type],[dflt_grp_nm] FROM corpcardcharges";
                    lstCCEmployeeInfo = repoCorpCardCharges.Executequery(querySelecet + queryWhere).ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
                return lstCCEmployeeInfo;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public List<EntityCorpCardInfo> GetSingleTERInfo(string queryWhere)
        {
            try
            {

                CorpCardChargesRepository<EntityCorpCardInfo> repoCorpCardCharges = null;
                repoCorpCardCharges = new CorpCardChargesRepository<EntityCorpCardInfo>();
                List<EntityCorpCardInfo> lstCCEmployeeInfo = new List<EntityCorpCardInfo>();
                try
                {
                    var parameters = new DynamicParameters();
                    queryWhere = " where TER_Num =" + queryWhere + " order by Seq_num desc";
                    string querySelect = "SELECT [TER_Num],[cm_name],[emp_id],[Seq_num],[bill_acct_num],[charge_dt],[insert_date] ,[billdate],[insert_dt],[amount],[localamount],[description],Case when [Status] = 1 THEN 'Unsubmitted' when[Status] = 2 THEN 'Submitted' when[Status] = 3 THEN 'Not Compliant' when[Status] = 4 THEN 'Approved' when[Status] = 5 THEN 'Saved' when[Status] = 6 THEN 'Trip Cancelled / Pattern Changed' when[Status] = 7 THEN 'Personal Charge' when[Status] = 8 THEN 'Other' when[Status] = 9 THEN 'Submitted - Not Processed' when[Status] = 10 THEN 'Denied' when[Status] = 11 THEN 'Okay To Pay' when[Status] = 12 THEN 'Approved & Audited' END as [Status],[CCCMonthly_ID],[update_date],[managername] ,[manageremail],[cardtype],[businesspurposes],[emp_type],[dflt_grp_nm] FROM corpcardcharges";
                    lstCCEmployeeInfo = repoCorpCardCharges.Executequery(querySelect + queryWhere).ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
                return lstCCEmployeeInfo;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }

        public List<EntityIncidentDetails> GetIncidentDetails(int incidentId, string incidentQuery)
        {
            try
            {
                CorpCardChargesRepository<EntityIncidentDetails> repoIncidentDetails = null;
                repoIncidentDetails = new CorpCardChargesRepository<EntityIncidentDetails>();

                List<EntityIncidentDetails> lstIncidentdetails = new List<EntityIncidentDetails>();
                try
                {
                    lstIncidentdetails = repoIncidentDetails.Executequery(incidentQuery).ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
                return lstIncidentdetails;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
    }
}
