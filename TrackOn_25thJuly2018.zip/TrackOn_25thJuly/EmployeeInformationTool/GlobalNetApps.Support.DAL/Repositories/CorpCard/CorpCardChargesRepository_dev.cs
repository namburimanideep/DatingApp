﻿namespace GlobalNetApps.Support.DAL.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Configuration;
    using GlobalNetApps.Support.DAL.Interfaces;
    using GlobalNetApps.Support.DAL.Entites;
    using Dapper;
    public class CorpCardChargesRepository_dev<T> : BaseRepository<T>, ICorpCardCharges_dev
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(CorpCardChargesRepository<T>));
        public CorpCardChargesRepository_dev()
            : base(ConfigurationManager.ConnectionStrings["CorpCardDev"].ConnectionString)
        {

        }

        public List<EntityGetCCCMonthlyId> GetCCCMonthly_ID(string newempId, string oldempId, string query)
        {
            try
            {

                CorpCardChargesRepository_dev<EntityGetCCCMonthlyId> repoCorpCardCharges = null;
                repoCorpCardCharges = new CorpCardChargesRepository_dev<EntityGetCCCMonthlyId>();
                List<EntityGetCCCMonthlyId> lstCCCMonthlyId = new List<EntityGetCCCMonthlyId>();
                try
                {
                    var parameters = new DynamicParameters();
                    parameters.Add("@new_empId", newempId);
                    parameters.Add("@old_empId", oldempId);
                    lstCCCMonthlyId = repoCorpCardCharges.Executequery(query).ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
                return lstCCCMonthlyId;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
    }

}
