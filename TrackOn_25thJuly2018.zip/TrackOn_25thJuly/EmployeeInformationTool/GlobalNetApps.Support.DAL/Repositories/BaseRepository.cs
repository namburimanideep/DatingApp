﻿namespace GlobalNetApps.Support.DAL.Repositories
{
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Diagnostics.CodeAnalysis;
    using System.Threading.Tasks;
    using Dapper;
    using System.Reflection;
    [AttributeUsage(AttributeTargets.Property)]
    public class DapperKey : Attribute
    {
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class DapperIgnore : Attribute
    {
    }
    /// <summary>
    /// BaseRepository class implemented from Repository interface
    /// </summary>
    /// <typeparam name="T">Type of object</typeparam>
    [SuppressMessage("StyleCop.CSharp.LayoutRules", "SA1513:ClosingCurlyBracketMustBeFollowedByBlankLine", Justification = "Reviewed.")]
    public class BaseRepository<T> : IRepository<T>
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(BaseRepository<T>));
        private readonly string connectionstring;
        public BaseRepository(string connectionstring)
        {
            this.connectionstring = connectionstring;
        }
        /// <summary>
        /// Gets or Sets table name
        /// </summary>
        public string TableName
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets Connection string value
        /// </summary>
        internal IDbConnection Connection
        {
            get
            {
                return new SqlConnection(this.connectionstring);
            }

            set
            {
                this.Connection = value;
            }
        }
        /// <summary>
        /// Add Async
        /// </summary>
        /// <typeparam name="Y">return type of object</typeparam>
        /// <param name="item">item parameter which needs to be added</param>
        /// <returns>item parameter</returns>
        public Task<T> AddAsync<Y>(T item)
        {
            throw new NotImplementedException();
        }
        public Task<bool> UpdateAsync(T item)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> Executequery(string query)
        {

            using (IDbConnection cn = Connection)
            {
                cn.Open();
                return cn.Query<T>(query);
            }
           
        }
        public IEnumerable<T> FindByQuery(string query)
        {
            try
            {
                IEnumerable<T> items = null;

                using (IDbConnection cn = this.Connection)
                {
                    cn.Open();
                    items = cn.Query<T>(query);
                }

                return items;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
        
        public IEnumerable<dynamic> FindByQuerydynamic(string query)
        {
            try
            {
                IEnumerable<dynamic> items = null;

                using (IDbConnection cn = this.Connection)
                {
                    cn.Open();
                    items = cn.Query(query);
                }

                return items;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public IEnumerable<T> ExecuteStoredProcedure(string spName, dynamic param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    return cn.Query<T>(spName, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public IEnumerable<T> ExecuteStoredProcedure(string spName)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    cn.Open();
                    return cn.Query<T>(spName, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }

        public async Task<IEnumerable<T>> ExecuteStoredProcedureAsync(string spName, dynamic param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    return await cn.QueryAsync<T>(spName, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public int ExecuteScalar(string spname, dynamic param)
        {
            try
            {
                int returnval = 0;
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    List<dynamic> xyz = new List<dynamic>();
                    var res = cn.Query(spname, parameters, commandType: CommandType.StoredProcedure);
                    foreach (IDictionary<string, object> row in res)
                    {
                        foreach (var pair in row)
                        {
                            returnval = Convert.ToInt32(pair.Value);
                        }
                    }
                }
                return returnval;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }

        public Y ExecuteScalar<Y>(string spname, dynamic param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    var retvalue = cn.Query<Y>(spname, parameters, commandType: CommandType.StoredProcedure);
                    foreach (dynamic temp in retvalue)
                    {
                        return Convert.ChangeType(temp.ToString(), typeof(Y));
                    }
                }
                return default(Y);
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public async Task<Y> ExecuteScalarAsync<Y>(string spname, dynamic param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    var retvalue = await cn.QueryAsync(spname, parameters, commandType: CommandType.StoredProcedure);
                    foreach (dynamic temp in retvalue)
                    {
                        return Convert.ChangeType(temp.Result, typeof(Y));
                    }
                }
                return default(Y);
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public object ExecuteScalarList(string spname, object param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    return cn.Query(spname, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public async Task<object> ExecuteScalarListAsync(string spname, object param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    return await cn.QueryAsync(spname, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }

        public void ExecuteNonQuery(string spname, dynamic param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    var res = cn.Query(spname, parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }

        }
        public Tuple<List<T>, List<T>> ExecuteMultipleTables(string spName, dynamic param)
        {
            try
            {
                using (IDbConnection cn = this.Connection)
                {
                    var parameters = (object)param;
                    cn.Open();
                    var reader = cn.QueryMultiple(spName, parameters, commandType: CommandType.StoredProcedure);
                    var lst1 = reader.Read<T>().ToList();
                    var lst2 = reader.Read<T>().ToList();
                    Tuple<List<T>, List<T>> returnTuple = new Tuple<List<T>, List<T>>(lst1, lst2);
                    return returnTuple;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        //public Tuple<IEnumerable<T1>, IEnumerable<T2>> GetMultipleResultSets<T1, T2>(string sql, object parameters,
        //                                 Func<GridReader, IEnumerable<T1>> func1,
        //                                 Func<GridReader, IEnumerable<T2>> func2)
        //{
        //    var objs = getMultiple(sql, parameters, func1, func2);
        //    return Tuple.Create(objs[0] as IEnumerable<T1>, objs[1] as IEnumerable<T2>);
        //}
        //private List<object> getMultiple(string sql, object parameters, params Func<GridReader, object>[] readerFuncs)
        //{
        //    var returnResults = new List<object>();
        //    using (IDbConnection cn = this.Connection)
        //    {
        //        var gridReader = cn.QueryMultiple(sql, parameters, commandType: CommandType.StoredProcedure);

        //        foreach (var readerFunc in readerFuncs)
        //        {
        //            var obj = readerFunc(gridReader);
        //            returnResults.Add(obj);
        //        }
        //    }

        //    return returnResults;
        //}
        /// <summary>
        /// The Add
        /// </summary>
        /// <param name="item">item parameter which needs to be added</param>
        /// <returns>item parameter</returns>
        public T Add(T item)
        {
            try
            {
                var propertyContainer = ParseProperties(item);
                var sql = string.Format("INSERT INTO [{0}] ({1}) VALUES (@{2}) SELECT CAST(scope_identity() AS int)",
                    typeof(T).Name,
                    string.Join(",", propertyContainer.ValueNames),
                    string.Join(",@", propertyContainer.ValueNames));

                using (IDbConnection cn = this.Connection)
                {
                    var id = cn.Query<int>(sql, propertyContainer.ValuePairs, commandType: CommandType.Text).First();
                    SetId(item, id, propertyContainer.IdPairs);
                }
                return item;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public void AddMultiple(List<T> items)
        {
            try
            {
                var propertyContainer = ParseProperties(items.FirstOrDefault());
                var sql = string.Format("INSERT INTO [{0}] ({1}) VALUES (@{2}) SELECT CAST(scope_identity() AS int)",
                    typeof(T).Name,
                    string.Join(",", propertyContainer.ValueNames),
                    string.Join(",@", propertyContainer.ValueNames));

                using (IDbConnection cn = this.Connection)
                {
                    cn.Execute(sql, items);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
        public T Update(T item, object keyColumn)
        {
            try
            {
                var parameters = (object)this.Mapping(item);
                var propertyContainer = ParseProperties(item);
                var param = propertyContainer.ValueNames.Select(name => name + "=@" + name).ToList();
                var sql = string.Format("UPDATE {0} SET {1} WHERE {2}=@ID",
                   typeof(T).Name,
                   string.Join(",", param), keyColumn);

                using (IDbConnection cn = this.Connection)
                {
                    cn.Execute(sql, parameters);
                }
                return item;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
        public bool Remove(int id, object keyColumn)
        {
            try
            {

                using (IDbConnection cn = this.Connection)
                {
                    cn.Open();
                    //return cn.Execute("DELETE FROM " + typeof(T).Name + " WHERE @KeyColumn=@ID", new { ID = id.ToString(), KeyColumn = keyColumn.ToString() }) > 0;
                    return cn.Execute("DELETE FROM " + typeof(T).Name + " WHERE " + keyColumn.ToString() + "=" + id.ToString()) > 0;
                }
            }
            catch (Exception ex) 
            {
              Log.Error(ex.Message);
               throw (ex);
            }
        }
        internal virtual dynamic Mapping(T item)
        {
            try
            {
                return item;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        public void SetId<T>(T obj, int id, IDictionary<string, object> propertyPairs)
        {
            try
            {
                if (propertyPairs.Count == 1)
                {
                    var propertyName = propertyPairs.Keys.First();
                    var propertyInfo = obj.GetType().GetProperty(propertyName);
                    if (propertyInfo.PropertyType == typeof(int))
                    {
                        propertyInfo.SetValue(obj, id, null);
                    }
                }
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        private static PropertyContainer ParseProperties<T>(T obj)
        {
            try
            {
                var propertyContainer = new PropertyContainer();

                var typeName = typeof(T).Name;
                var validKeyNames = new[] { "Id",
            string.Format("{0}Id", typeName), string.Format("{0}_Id", typeName) };

                var properties = typeof(T).GetProperties();
                foreach (var property in properties)
                {
                    // Skip reference types (but still include string!)
                    if (property.PropertyType.IsClass && property.PropertyType != typeof(string))
                        continue;

                    // Skip methods without a public setter
                    if (property.GetSetMethod() == null)
                        continue;

                    // Skip methods specifically ignored
                    if (property.IsDefined(typeof(DapperIgnore), false))
                        continue;

                    var name = property.Name;
                    var value = typeof(T).GetProperty(property.Name).GetValue(obj, null);

                    if (property.IsDefined(typeof(DapperKey), false) || validKeyNames.Contains(name))
                    {
                        propertyContainer.AddId(name, value);
                    }
                    else
                    {
                        propertyContainer.AddValue(name, value);
                    }
                }

                return propertyContainer;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }
        /// <summary>
        /// Removes the default DateTime value and update to null.
        /// </summary>
        /// <param name="item">item parameter which needs to change its default DateTime value</param>
        /// <returns>changed DateTime value</returns>
        public static dynamic RemoveDefaultDateTimeValues(dynamic item)
        {
            try
            {
                foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                {
                    if (propertyInfo.PropertyType == typeof(DateTime))
                    {
                        DateTime date = (DateTime)propertyInfo.GetValue(item, null);
                        if (date.Equals(DateTime.MinValue))
                        {
                            propertyInfo.SetValue(item, DateTime.Now, null);
                        }
                    }
                }
                return item;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
               throw (ex);
            }
        }
    }

    public class PropertyContainer
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(PropertyContainer));
        private readonly Dictionary<string, object> _ids;
        private readonly Dictionary<string, object> _values;

        #region Properties

        public IEnumerable<string> IdNames
        {
            get { return _ids.Keys; }
        }

        public IEnumerable<string> ValueNames
        {
            get { return _values.Keys; }
        }

        public IEnumerable<string> AllNames
        {
            get { return _ids.Keys.Union(_values.Keys); }
        }

        public IDictionary<string, object> IdPairs
        {
            get { return _ids; }
        }

        public IDictionary<string, object> ValuePairs
        {
            get { return _values; }
        }

        public IEnumerable<KeyValuePair<string, object>> AllPairs
        {
            get { return _ids.Concat(_values); }
        }

        #endregion

        #region Constructor

        public PropertyContainer()
        {
            _ids = new Dictionary<string, object>();
            _values = new Dictionary<string, object>();
        }

        #endregion

        #region Methods

        public void AddId(string name, object value)
        {
            try
            {
                _ids.Add(name, value);
            }
            catch (Exception ex)
            {
              Log.Error(ex.Message);
               throw (ex);
            }
        }

        public void AddValue(string name, object value)
        {
            try
            {
                _values.Add(name, value);
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }

        #endregion
    }
}
