﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using GlobalNetApps.Support.DAL.Interfaces;
using GlobalNetApps.Support.DAL.Entites;
using Dapper;

namespace GlobalNetApps.Support.DAL.Repositories
{
    public class MasterDataRepository<T> : BaseRepository<T>, IMasterData
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(MasterDataRepository<T>));
        public MasterDataRepository()
            : base(ConfigurationManager.ConnectionStrings["Atlas_TCS"].ConnectionString)
        {

        }
        public List<EntityAssociates> GetAssociates()
        {

            MasterDataRepository<EntityAssociates> repoAssociates = null;
            repoAssociates = new MasterDataRepository<EntityAssociates>();
            List<EntityAssociates> lstAssociates = new List<EntityAssociates>();
            try
            {
                var parameters = new DynamicParameters();
                string querySelecet = "SELECT * FROM Master_Associates where IsActive=1";
                lstAssociates = repoAssociates.Executequery(querySelecet).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstAssociates;
        }
        public int AddAssociates(EntityAssociates entityAssociate)
        {
            return 0;
        }
        public int UpdateAssociates(EntityAssociates entityAssociate)
        {
            return 0;
        }

        public int DeleteAssociates(int Id)
        {
            MasterDataRepository<EntityAssociates> repoAssociates = null;
            repoAssociates = new MasterDataRepository<EntityAssociates>();
            List<EntityAssociates> lstAssociates = new List<EntityAssociates>();
            try
            {
                var parameters = new DynamicParameters();
                string querySelecet = "update Master_Associates set IsActive=0 where id="+ Id;
                repoAssociates.Executequery(querySelecet);
               // int c = repoAssociates.ExecuteNonQuery(querySelecet);
                return 1;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return 0;
            }
           
        }

        public List<EntityGetCCCMonthlyId> GetCCCMonthly_ID(string newempId, string oldempId, string query)
        {
            CorpCardChargesRepository_dev<EntityGetCCCMonthlyId> repoCorpCardCharges = null;
            repoCorpCardCharges = new CorpCardChargesRepository_dev<EntityGetCCCMonthlyId>();
            List<EntityGetCCCMonthlyId> lstCCCMonthlyId = new List<EntityGetCCCMonthlyId>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@new_empId", newempId);
                parameters.Add("@old_empId", oldempId);
                lstCCCMonthlyId = repoCorpCardCharges.Executequery(query).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstCCCMonthlyId;
        }
    }
}
