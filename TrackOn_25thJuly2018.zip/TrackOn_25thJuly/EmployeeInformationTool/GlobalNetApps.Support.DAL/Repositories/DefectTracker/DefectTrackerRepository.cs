﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using GlobalNetApps.Support.DAL.Interfaces;
using GlobalNetApps.Support.DAL.Entites;
using Dapper;
using System.Data;

namespace GlobalNetApps.Support.DAL.Repositories
{
    public class DefectTrackerRepository<T> : BaseRepository<T>
    {
        string query = string.Empty;
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(DefectTrackerRepository<T>));
        public DefectTrackerRepository()
            : base(ConfigurationManager.ConnectionStrings["Atlas_TCS"].ConnectionString)
        { }

        public List<EntityDefects> getDefects()
        {
            DefectTrackerRepository<EntityDefects> repoEfforts = null;
            repoEfforts = new DefectTrackerRepository<EntityDefects>();
            List<EntityDefects> lstDefects = new List<EntityDefects>();
            try
            {
                lstDefects = repoEfforts.Executequery("select * from [vGetOpenDefects]").ToList();
                lstDefects.Reverse();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstDefects;
        }

        public List<EntityDefects> UploadDefects(EntityDefects entityDefects)
        {
            DefectTrackerRepository<EntityDefects> repoEfforts = null;
            repoEfforts = new DefectTrackerRepository<EntityDefects>();
            List<EntityDefects> lstDefects = new List<EntityDefects>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@Name", entityDefects.Name);
                parameters.Add("@ContentType", entityDefects.ContentType);
                parameters.Add("@Data", entityDefects.Data);
                parameters.Add("@Description", entityDefects.Description);
                parameters.Add("@createdBy", entityDefects.CreatedBy);
                lstDefects = repoEfforts.ExecuteStoredProcedure("udsp_Add_Defect", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstDefects;
        }
    }

}