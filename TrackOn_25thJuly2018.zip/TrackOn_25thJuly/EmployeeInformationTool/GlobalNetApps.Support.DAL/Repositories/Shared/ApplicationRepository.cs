﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using GlobalNetApps.Support.DAL.Interfaces;
using GlobalNetApps.Support.DAL.Entites;
using Dapper;
namespace GlobalNetApps.Support.DAL.Repositories
{
    public class ApplicationRepository<T> : BaseRepository<T>, IApplication
    {
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(ApplicationRepository<T>));
        public ApplicationRepository()
            : base(ConfigurationManager.ConnectionStrings["Atlas_TCS"].ConnectionString)
        {

        }
        public List<EntityApplications> getApplicationDetails()
        {
            try
            {
                ApplicationRepository<EntityApplications> repoApplications = null;
                repoApplications = new ApplicationRepository<EntityApplications>();
                List<EntityApplications> lstApplications = new List<EntityApplications>();
                try
                {
                    var parameters = new DynamicParameters();
                    lstApplications = repoApplications.Executequery("SELECT * FROM [Atlas_TCS].[dbo].[vGetApplicationDetails]").ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
                return lstApplications;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message); 
                throw (ex);
            }
        }
    }
}
