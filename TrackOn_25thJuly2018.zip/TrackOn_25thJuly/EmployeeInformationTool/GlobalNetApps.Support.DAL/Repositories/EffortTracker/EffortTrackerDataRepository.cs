﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using GlobalNetApps.Support.DAL.Interfaces;
using GlobalNetApps.Support.DAL.Entites;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace GlobalNetApps.Support.DAL.Repositories
{
    public class EffortTrackerDataRepository<T> : BaseRepository<T>, IEffortTracker
    {
        string query = string.Empty;
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(EffortTrackerDataRepository<T>));
        public EffortTrackerDataRepository()
            : base(ConfigurationManager.ConnectionStrings["Atlas_TCS"].ConnectionString)
        {

        }

        #region Incidents
        public List<Entity_Rpt_Incident> getEntireTrackData(string userName, int getAllData)
        {
            EffortTrackerDataRepository<Entity_Rpt_Incident> repoIncidentDetails = null;
            repoIncidentDetails = new EffortTrackerDataRepository<Entity_Rpt_Incident>();
            List<Entity_Rpt_Incident> lstEfforts = new List<Entity_Rpt_Incident>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@userName", userName);
                parameters.Add("@getAllIncidents", getAllData);
                lstEfforts = repoIncidentDetails.ExecuteStoredProcedure("udsp_Get_EntireTrackData", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstEfforts;
        }
        public List<EntityIncident> getIncidents(string username)
        {
            EffortTrackerDataRepository<EntityIncident> repoEfforts = null;
            repoEfforts = new EffortTrackerDataRepository<EntityIncident>();
            List<EntityIncident> lstEfforts = new List<EntityIncident>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@username", username.Trim().Replace(" ", "."));
                lstEfforts = repoEfforts.ExecuteStoredProcedure("udsp_Get_Incidents", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstEfforts;
        }
        public List<EntityIncidentHistory> getHistory(int incidentId)
        {
            EffortTrackerDataRepository<EntityIncidentHistory> repoEfforts = null;
            repoEfforts = new EffortTrackerDataRepository<EntityIncidentHistory>();
            List<EntityIncidentHistory> lstIncidentHistory = new List<EntityIncidentHistory>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@IncidentId", incidentId);
                lstIncidentHistory = repoEfforts.ExecuteStoredProcedure("udsp_GetIncidentLatestHistory", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstIncidentHistory;
        }
        public int addIncident(EntityIncident addIncident)
        {
            try
            {

                var parameters = new DynamicParameters();
                EffortTrackerDataRepository<EntityResult> repoMasterTable = null;
                repoMasterTable = new EffortTrackerDataRepository<EntityResult>();
                parameters.Add("@IncidentID", addIncident.IncidentId.ToString());
                parameters.Add("@Severity", addIncident.Severity);
                parameters.Add("@Priority", addIncident.Priority);
                parameters.Add("@AlertType", addIncident.AlertType);
                parameters.Add("@ApplicationName", addIncident.ApplicationName);
                parameters.Add("@AssignedDate", addIncident.AssignedDate);
                parameters.Add("@IncidentDescription", addIncident.IncidentDescription);
                parameters.Add("@DailyUpdates", addIncident.DailyUpdates);
                parameters.Add("@Category", Convert.ToInt32(addIncident.Category));
                parameters.Add("@Owner", addIncident.Owner);
                parameters.Add("@createdBy", addIncident.CreatedBy);
                List<EntityResult> entityResult = repoMasterTable.ExecuteStoredProcedure("udsp_Add_Incident", parameters).ToList();
                return entityResult[0].result;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return 0;

            }
        }
        public int UpdateIncident(EntityIncidentHistory entityIncidentHistory)
        {
            EffortTrackerDataRepository<EntityIncidentHistory> repoEfforts = null;
            repoEfforts = new EffortTrackerDataRepository<EntityIncidentHistory>();
            List<EntityIncidentHistory> lstIncidentHistory = new List<EntityIncidentHistory>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@IncidentId", entityIncidentHistory.Id);
                parameters.Add("@DailyUpdates", entityIncidentHistory.DailyUpdates);
                parameters.Add("@CurrentStatus", entityIncidentHistory.CurrentStatus);
                if (!string.IsNullOrEmpty(entityIncidentHistory.RootCause) && entityIncidentHistory.RootCause != "0")
                {
                    parameters.Add("@RootCause", entityIncidentHistory.RootCause);
                    parameters.Add("@Resolution", entityIncidentHistory.Resolution);
                }
                if (!string.IsNullOrEmpty(entityIncidentHistory.ResolvedDate))
                {
                    parameters.Add("@ResolvedDate", entityIncidentHistory.ResolvedDate);
                }
                parameters.Add("@CreatedBy", entityIncidentHistory.CreatedBy);
                lstIncidentHistory = repoEfforts.ExecuteStoredProcedure("udsp_UpdateIncident", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstIncidentHistory.Count;
        }
        public List<EntitySLA> GetDetailsForSLA(string username)
        {
            EffortTrackerDataRepository<EntitySLA> repoSLA = null;
            repoSLA = new EffortTrackerDataRepository<EntitySLA>();
            List<EntitySLA> lstSLA = new List<EntitySLA>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@username", username.Trim().Replace(" ", "."));
                lstSLA = repoSLA.ExecuteStoredProcedure("udsp_GetIncidentDetailsForSLA", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstSLA;
        }
        public int UpdateSLATimings(List<EntitySLA> lstSLA)
        {
            EffortTrackerDataRepository<EntitySLA> repoSLA = null;
            repoSLA = new EffortTrackerDataRepository<EntitySLA>();
            int result = 0;
            try
            {
                int AssociateId = getMasterDataFromSP(lstSLA[0].CreatedBy.ToString(), "udsp_Get_AssociateIdByUserName")[0].id;
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[5]
                {
                new DataColumn("IncidentId", typeof(int)),
                new DataColumn("ResponseTimeSLA_PHrs", typeof(int)),
                new DataColumn("ResolutionSLA_PHrs", typeof(int)),
                new DataColumn("CreatedBy",typeof(string)),
                new DataColumn("CreatedDateTime",typeof(string))
                });
                string whereCondition = "";
                for (int i = 0; i < lstSLA.Count; i++)
                {
                    if (i == 0)
                    {
                        whereCondition = lstSLA[i].ID.ToString();
                    }
                    else
                    {
                        whereCondition = whereCondition + "," + lstSLA[i].ID.ToString();
                    }
                    dt.Rows.Add(lstSLA[i].ID, lstSLA[i].ResponseTimeSLA_PHrs, lstSLA[i].ResolutionSLA_PHrs, AssociateId, DateTime.Now);
                }
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Atlas_TCS"].ConnectionString);
                con.Open();
                using (var objTrans = con.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    SqlCommand objCmd = new SqlCommand("update Incident_SLA set IsActive=0,LastUpdatedDateTime=" + "'" + DateTime.Now.ToString() + "'" + ",LastUpdatedby=" + AssociateId + " where IncidentId in (" + whereCondition + ")", con, objTrans);
                    try
                    {
                        using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con, SqlBulkCopyOptions.Default, objTrans))
                        {
                            sqlBulkCopy.DestinationTableName = "dbo.Incident_SLA";
                            sqlBulkCopy.ColumnMappings.Add("IncidentId", "IncidentId");
                            sqlBulkCopy.ColumnMappings.Add("ResponseTimeSLA_PHrs", "ResponseTimeSLA_PHrs");
                            sqlBulkCopy.ColumnMappings.Add("ResolutionSLA_PHrs", "ResolutionSLA_PHrs");
                            sqlBulkCopy.ColumnMappings.Add("CreatedBy", "CreatedBy");
                            sqlBulkCopy.ColumnMappings.Add("CreatedDateTime", "CreatedDateTime");
                            objCmd.ExecuteNonQuery();
                            sqlBulkCopy.WriteToServer(dt);
                        }
                        objTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Log.Error(ex.Message);
                        objTrans.Rollback();
                    }
                    finally
                    {
                        result = 1;
                        con.Close();
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return result;
            }

        }
        #endregion

        #region efforts
        public List<EntityEffort> getEfforts(string username)
        {
            EffortTrackerDataRepository<EntityEffort> repoEfforts = null;
            repoEfforts = new EffortTrackerDataRepository<EntityEffort>();
            List<EntityEffort> lstEfforts = new List<EntityEffort>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@username", username.Trim().Replace(" ", "."));
                lstEfforts = repoEfforts.ExecuteStoredProcedure("udsp_Get_Efforts", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstEfforts;
        }
        public EntityEffort addEfforts(EntityEffort addEffort)
        {
            try
            {
                EffortTrackerDataRepository<EntityEffort> repoEffort = null;
                repoEffort = new EffortTrackerDataRepository<EntityEffort>();
                EntityEffort entityEffort = new EntityEffort();
                var parameters = new DynamicParameters();
                parameters.Add("@IncidentId", addEffort.IncidentId.ToString());
                parameters.Add("@userName", addEffort.AssociateName);
                parameters.Add("@EffortSpentInHrs", addEffort.EffortSpentInHRs);
                parameters.Add("@EffortDate", addEffort.EffortDate);
                parameters.Add("@EffortType", Convert.ToInt32(addEffort.EffortType));
                entityEffort = repoEffort.ExecuteStoredProcedure("udsp_Add_Effort", parameters).ToList()[0];
                return entityEffort;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw ex;
            }
        }
        public int updateEffort(EntityEffort entityEffort)
        {
            try
            {
                var parameters = new DynamicParameters();
                EffortTrackerDataRepository<EntityEffort> repoEntityEffort = null;
                repoEntityEffort = new EffortTrackerDataRepository<EntityEffort>();
                parameters.Add("@EffortId", entityEffort.EffortId);
                parameters.Add("@EffortDate", entityEffort.EffortDate);
                parameters.Add("@EffortType", entityEffort.EffortType);
                parameters.Add("@EffortSpentInHrs ", entityEffort.EffortSpentInHRs);
                repoEntityEffort.ExecuteStoredProcedure("udsp_Update_Effort", parameters);
                return 1;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return 0;
            }
        }
        public int deleteEffort(int effortId)
        {
            try
            {
                var parameters = new DynamicParameters();
                EffortTrackerDataRepository<EntityEffort> repoEntityEffort = null;
                repoEntityEffort = new EffortTrackerDataRepository<EntityEffort>();
                parameters.Add("@EffortId", effortId);
                repoEntityEffort.ExecuteStoredProcedure("udsp_Delete_Effort", parameters);
                return 1;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return 0;
            }
        }
        #endregion efforts

        #region Reports
        public List<Entity_Rpt_Incident> getDashBoard(EntityGetDashBoard entityDashBoard)
        {
            EffortTrackerDataRepository<Entity_Rpt_Incident> repoIncidentDetails = null;
            repoIncidentDetails = new EffortTrackerDataRepository<Entity_Rpt_Incident>();
            List<Entity_Rpt_Incident> lstEfforts = new List<Entity_Rpt_Incident>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@AssignedFromDate", entityDashBoard.AssignedFromDate);
                parameters.Add("@AssignedToDate", entityDashBoard.AssignedToDate);
                parameters.Add("@type", entityDashBoard.Type);
                parameters.Add("@status", entityDashBoard.status);
                parameters.Add("@track", entityDashBoard.track);
                lstEfforts = repoIncidentDetails.ExecuteStoredProcedure("udsp_Rpt_Get_DashBoard", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstEfforts;
        }
        public List<Entity_Rpt_GetDashBoardByGrouping> getReport(EntityGetDashBoard entityDashBoard)
        {
            EffortTrackerDataRepository<Entity_Rpt_GetDashBoardByGrouping> repoIncidentDetails = null;
            repoIncidentDetails = new EffortTrackerDataRepository<Entity_Rpt_GetDashBoardByGrouping>();
            List<Entity_Rpt_GetDashBoardByGrouping> lstEfforts = new List<Entity_Rpt_GetDashBoardByGrouping>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@AssignedFromDate", entityDashBoard.AssignedFromDate);
                parameters.Add("@AssignedToDate", entityDashBoard.AssignedToDate);
                parameters.Add("@type", entityDashBoard.Type);
                parameters.Add("@status", entityDashBoard.status);
                parameters.Add("@track", entityDashBoard.track);
                parameters.Add("@reportId", entityDashBoard.ReportId);
                lstEfforts = repoIncidentDetails.ExecuteStoredProcedure("udsp_Rpt_ExecReportSP", parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstEfforts;
        }
        #endregion
        public List<EntityMasterTable> getMasterDataFromSP(string username, string storeProc)
        {
            EffortTrackerDataRepository<EntityMasterTable> repoEfforts = null;
            repoEfforts = new EffortTrackerDataRepository<EntityMasterTable>();
            List<EntityMasterTable> lstEntityMasterTable = new List<EntityMasterTable>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                lstEntityMasterTable = repoEfforts.ExecuteStoredProcedure(storeProc, parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstEntityMasterTable;
        }
        public List<EntityMasterTable> getMasterDataFromTrackId(int trackId, string storeProc)
        {
            EffortTrackerDataRepository<EntityMasterTable> repoEfforts = null;
            repoEfforts = new EffortTrackerDataRepository<EntityMasterTable>();
            List<EntityMasterTable> lstEntityMasterTable = new List<EntityMasterTable>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@trackId", trackId);
                lstEntityMasterTable = repoEfforts.ExecuteStoredProcedure(storeProc, parameters).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstEntityMasterTable;
        }
        public List<EntityMasterTable> getMasterData(string inputQuery)
        {
            try
            {
                EffortTrackerDataRepository<EntityMasterTable> repoMasterTable = null;
                repoMasterTable = new EffortTrackerDataRepository<EntityMasterTable>();
                List<EntityMasterTable> lstEntityMasterTable = new List<EntityMasterTable>();
                try
                {
                    var parameters = new DynamicParameters();
                    string querySelecet = inputQuery;
                    lstEntityMasterTable = repoMasterTable.Executequery(inputQuery).ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
                return lstEntityMasterTable;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getApplication(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_Applications");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getRoles(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_Roles");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getIncidentDropDown(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_GetIncidentsForTrack");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }

        }
        public List<EntityMasterTable> getTypeOfIncident(int trackId)
        {
            try
            {
                return getMasterDataFromTrackId(trackId, "udsp_Get_EffortTypeByTrack");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }

        }
        public List<EntityMasterTable> getName(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_Associates");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }

        public List<EntityMasterTable> getEffortType(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_EffortType");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getTypeOfIncident(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_Category");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }

        public List<EntityMasterTable> getRootCause(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_RootCause");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getResolution(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_Resolution");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getTrackId(string userName)
        {
            try
            {
                return getMasterDataFromSP(userName, "udsp_Get_TrackId");
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getStatus()
        {
            try
            {
                query = "select id,status as value from Master_status";
                return getMasterData(query);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getReports()
        {
            try
            {
                query = "select id,[Description] as value from Incident_ReportMapping order by [Description]";
                return getMasterData(query);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getAlertType()
        {
            try
            {
                query = "select id,AlertType as value from Master_Alert";
                return getMasterData(query);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
        public List<EntityMasterTable> getPriority()
        {
            try
            {
                query = "select id,Priority as value from Master_Priority";
                return getMasterData(query);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }

        public List<EntityMasterTable> getSeverity()
        {
            try
            {
                query = "select id,Severity as value from Master_Severity";
                return getMasterData(query);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }

        //public List<EntityMasterTable> getEffortHistory()
        //{
        //    query = "  select IEH.ID, CONCAT( CONCAT((DateName( DAY ,IEH.EffortDate)),'/',(DateName( month ,IEH.EffortDate))),'(',IEH.EffortSpentInHrs,'Hrs)',  ' - ',IM.IncidentID,' - ',IM.IncidentDescription) AS Value FROM [Atlas_TCS].[dbo].[Incident_EffortHistory] IEH inner join Incident_Master IM on IM.ID = IEH.IncidentId ORDER BY IEH.ID DESC";
        //    return getMasterData(query);
        //}
        public List<EntityMasterTable> getOpenIncidentForTrack(string UserName)
        {
            List<EntityMasterTable> entityResult = new List<EntityMasterTable>();
            try
            {
                var parameters = new DynamicParameters();
                EffortTrackerDataRepository<EntityMasterTable> repoMasterTable = null;
                repoMasterTable = new EffortTrackerDataRepository<EntityMasterTable>();
                parameters.Add("@UserName", UserName);
                entityResult = repoMasterTable.ExecuteStoredProcedure("udsp_GetOpenIncidentsForTrack", parameters).ToList();
                return entityResult;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return entityResult;
            }
        }
        public List<EntityMasterTable> getTracks()
        {
            try
            {
                query = "select id,track as value from Master_tracks";
                return getMasterData(query);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw (ex);
            }
        }
    }
}
