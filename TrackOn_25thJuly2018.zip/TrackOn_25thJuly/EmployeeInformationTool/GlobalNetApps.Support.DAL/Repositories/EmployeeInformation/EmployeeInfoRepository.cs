﻿namespace GlobalNetApps.Support.DAL.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Configuration;
    using GlobalNetApps.Support.DAL.Interfaces;
    using GlobalNetApps.Support.DAL.Entites;
    using Dapper;
    public class EmployeeInfoRepository<T> : BaseRepository<T>, IEmployeeInfo
    {
        public EmployeeInfoRepository()
            : base(ConfigurationManager.ConnectionStrings["edw"].ConnectionString)
        {
        }
        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(typeof(EmployeeInfoRepository<T>));
        public List<EntityEmployeeInfo> GetEmployeeInfo(EntityGetEmpInfo getinfo)
        {
            try
            {

                bool flag = false;
                string query = "";
                string query2 = "";
                string final = string.Empty;
                string userNameByComma = string.Empty;
                if (!string.IsNullOrEmpty(getinfo.EmailId))
                {
                    query = query + "EMail= '" + getinfo.EmailId.Trim() + "'";
                    query2 = query2 + "Mail= '" + getinfo.EmailId.Trim() + "'";
                    flag = true;
                }
                if (!string.IsNullOrEmpty(getinfo.UserName))
                {
                    string usernames = getinfo.UserName.Trim();
                    string[] userNameLst = usernames.Split(',');
                    for (int i = 0; i < userNameLst.Length; i++)
                    {
                        string item = userNameLst[i].Trim();
                        final = final + "'" + item + "',";
                    }
                    userNameByComma = final.Substring(0, final.Length - 1);
                    if (flag == true)
                    {
                        query = query + " or " + "UserName in (" + userNameByComma.Trim() + ")";
                        query2 = query2 + " or " + "sAMAccountName in (" + userNameByComma.Trim() + ")";
                        //query = query + " or " + "UserName in ('" + getinfo.UserName.Trim() + "')";
                        //query2 = query2 + " or " + "sAMAccountName in ('" + getinfo.UserName.Trim() + "')";

                    }
                    else
                    {
                        query = query + "UserName in (" + userNameByComma.Trim() + ")";
                        query2 = query2 + "sAMAccountName in (" + userNameByComma.Trim() + ")";
                        //query = query + "UserName in ('" + getinfo.UserName.Trim() + "')";
                        //query2 = query2 + "sAMAccountName in ('" + getinfo.UserName.Trim() + "')";
                        flag = true;
                    }
                }
                if (getinfo.EmpId != null)
                {
                    if (flag == true)
                    {
                        query = query + " or " + "EmployeeId= " + getinfo.EmpId;
                        query2 = query2 + " or " + "EmployeeId= " + getinfo.EmpId;
                    }
                    else
                    {
                        query = query + "EmployeeId= " + getinfo.EmpId;
                        query2 = query2 + "EmployeeId= " + getinfo.EmpId;
                        flag = true;
                    }
                }
                if (!string.IsNullOrEmpty(getinfo.FullName))
                {
                    if (flag == true)
                    {
                        query = query + " or " + "EmployeeFullName like " + "'%" + getinfo.FullName.Trim() + "%'";
                        query2 = query2 + " or " + "FullName like " + "'%" + getinfo.FullName.Trim() + "%'";
                    }
                    else
                    {
                        query = query + "EmployeeFullName like " + "'%" + getinfo.FullName.Trim() + "%'";
                        query2 = query2 + "FullName like " + "'%" + getinfo.FullName.Trim() + "%'";
                        flag = true;
                    }
                }
                List<string> lstQuery = new List<string>();
                lstQuery.Add(" where " + query);
                lstQuery.Add(" where " + query2);
                string connection = System.Configuration.ConfigurationManager.ConnectionStrings["edw"].ConnectionString;
                EmployeeInfoRepository<EntityEmployeeInfo> repoPriceOut = null;
                repoPriceOut = new EmployeeInfoRepository<EntityEmployeeInfo>();
                List<EntityEmployeeInfo> lstEmployeeInfo = new List<EntityEmployeeInfo>();
                try
                {
                    var parameters = new DynamicParameters();
                    string q1 = "select [EmployeeId] as EmployeeId,[UserName] as UserName,[EmployeeFullName] as FullName,[EMail] as mail,[Company] as Company,[BusinessUnit] as [BusinessUnit],[EmployeeStatus] as EmployeeStatus,[EmployeeType] as EmployeeType,[doh] as HiringDate,[dor] as ResigningDate,[TerminationDate] as TerminationDate,'EI' as TableName FROM [DSWAREHOUSE].[DS_ADMIN].[L_EmployeeInformation]";
                    string q2 = "SELECT [EmployeeId] as EmployeeId,[sAMAccountName] as UserName,[FullName] as FullName,[Mail] as mail,[Company] as Company,'' as [BusinessUnit],'' as EmployeeStatus,'' as EmployeeType,'' as HiringDate,'' as ResigningDate,'' as TerminationDate,'AD' as TableName FROM [DSWAREHOUSE].[DS_ADMIN].[L_ActiveDirectory]";
                    string finalQuery = q1 + lstQuery[0] + " union " + q2 + lstQuery[1];
                    lstEmployeeInfo = repoPriceOut.Executequery(finalQuery).ToList();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                    return lstEmployeeInfo;
                }
                return lstEmployeeInfo;
            }
            catch (Exception ex)
            {
               Log.Error(ex.Message);
               throw (ex);
            }
        }

        public List<EntityVendorADDorMove> GetVendorInfo(string newID,string query)
        {  
            string connection = System.Configuration.ConfigurationManager.ConnectionStrings["edw"].ConnectionString;
            EmployeeInfoRepository<EntityVendorADDorMove> repoPriceOut = null;
            repoPriceOut = new EmployeeInfoRepository<EntityVendorADDorMove>();
            List<EntityVendorADDorMove> lstVendorInfo = new List<EntityVendorADDorMove>();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@new_empId", newID);

                lstVendorInfo = repoPriceOut.Executequery(query).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            return lstVendorInfo;
        }
    }
}
