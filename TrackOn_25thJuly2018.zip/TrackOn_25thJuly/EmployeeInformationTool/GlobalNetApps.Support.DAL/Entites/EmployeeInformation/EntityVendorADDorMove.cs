﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityVendorADDorMove
    {
        public string NewUserName { get; set; }
        public string OldUserName { get; set; }
        public string NewEmployeeId { get; set; }
        public string OldEmployeeId { get; set; }
        public string NewFullName { get; set; }
        public string OldFullName { get; set; }
        public string NewEmployeeStatus { get; set; }
        public string OldEmployeeStatus { get; set; }
        public string NewEmployeeDOH { get; set; }
        public string oldEmployeeDOH { get; set; }
        public string NewEmployeeEmail { get; set; }
        public string oldEmployeeEmail { get; set; }
        public string SequenceNumber { get; set; }
        public string TERNumber { get; set; }
        public string Cm_Name { get; set; }
        public string cccMonthlyid { get; set; }
        public string TableName { get; set; }


    }
}
