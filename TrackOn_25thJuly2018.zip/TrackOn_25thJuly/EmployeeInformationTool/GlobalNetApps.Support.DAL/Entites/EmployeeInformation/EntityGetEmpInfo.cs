﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.DAL.Entites
{
   public class EntityGetEmpInfo
    {
        public int? EmpId { get; set; }
        public string EmailId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }

    }
}
