﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntitySLA
    {
        public string IncidentID { get; set; }
        public string IncidentDescription { get; set; }
        public string ResolutionSLA_PHrs { get; set; }
        public string ResponseTimeSLA_PHrs { get; set; }
        public int ID { get; set; }
        public string CreatedBy { get; set; }        
    }
}
