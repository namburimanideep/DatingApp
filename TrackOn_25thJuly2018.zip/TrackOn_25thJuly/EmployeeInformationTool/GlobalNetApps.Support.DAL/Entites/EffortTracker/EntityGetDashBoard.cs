﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityGetDashBoard
    {
        public string AssignedFromDate { get; set; }
        public string AssignedToDate { get; set; }
        public string track { get; set; }
        public string Type { get; set; }
        public string status { get; set; }
        public string ReportId { get; set; }
    }
}
