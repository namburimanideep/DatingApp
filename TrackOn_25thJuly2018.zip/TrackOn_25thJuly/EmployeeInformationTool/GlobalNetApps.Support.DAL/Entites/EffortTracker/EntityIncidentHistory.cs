﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityIncidentHistory
    {
        public int Id { get; set; }
        public string IncidentId { get; set; }
        public string DailyUpdates { get; set; }
        public string CurrentStatus { get; set; }
        public string CreatedBy { get; set; }
        public string RootCause { get; set; }
        public string Resolution { get; set; }
        public string ResolvedDate { get; set; }        

    }
}
