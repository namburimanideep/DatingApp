﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityIncidentDetails
    {
        public string IncidentID { get; set; }
        public string SubjectLine { get; set; }
        public string AssignedDate { get; set; }
        public string RespondedDate { get; set; }
        public string SLAResponseTime { get; set; }

    }
}

