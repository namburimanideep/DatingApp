﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace GlobalNetApps.Support.DAL.Entites
{
    public class Entity_Rpt_Incident
    {
        public int Id { get; set; }
        public string IncidentId { get; set; }
        public string IncidentDescription { get; set; }
        public string DailyUpdates { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string RootCauseAndRemarks { get; set; }
        public string ResolutionCategory { get; set; }
        public string CurrentStatus { get; set; }
        public string Priority { get; set; }
        public string Severity { get; set; }
        public string AssignedDate { get; set; }
        public string ApplicationName { get; set; }
        public string ResolutionSLA_PHrs { get; set; }
        public string EffortInHours { get; set; }
        public string ResponseTimeSLA_PHrs { get; set; }
        public string Owner { get; set; }
        public string Track { get; set; }
        public string AlertType { get; set; }
        public string CreatedBy { get; set; }
        public string ResolvedDate { get; set; }
    }
}
