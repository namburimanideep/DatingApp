﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.DAL.Entites
{
   public class Entity_Rpt_GetDashBoardByGrouping
    {
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string AssignedDate { get; set; }
        public string CurrentStatus { get; set; }
        public string Count { get; set; }
        public string EffortInHours { get; set; }
        public string Track { get; set; }
        public string Name { get; set; }
    }
}
