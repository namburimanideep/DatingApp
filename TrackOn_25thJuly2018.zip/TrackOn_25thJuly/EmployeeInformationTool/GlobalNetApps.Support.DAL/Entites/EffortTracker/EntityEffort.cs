﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace GlobalNetApps.Support.DAL.Entites
{
   public class EntityEffort
    {
        public int EffortId { get; set; }
        public string IncidentId { get; set; }
        public string IncidentDescription { get; set; }        
        public string AssociateName { get; set; }
        public string EffortDate { get; set; }
        public string EffortSpentInHRs { get; set; }
        public string EffortType { get; set; }      
        public int IsActive { get; set; }       
    }
}
