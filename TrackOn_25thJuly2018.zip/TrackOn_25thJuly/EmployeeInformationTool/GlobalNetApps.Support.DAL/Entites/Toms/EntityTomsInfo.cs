﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityTomsInfo
    {
        public int EmployeeID { get; set; }
        public string UserName { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string EmployeePositionID { get; set; }
        public string SupervisorPositionID { get; set; }
        public string VPPositionID { get; set; }
        public string Location { get; set; }
        public string HireDate { get; set; }
        public string TerminationDate { get; set; }       
        public string CompanyCode { get; set; }
        public string DateTimeUploaded { get; set; }
        public string EmployeeType { get; set; }      
    }
}
