﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityApplications
    {
        public int Id { get; set; }
        public int Tier { get; set; }
        public string application { get; set; }
        public string complexity { get; set; }
        public string AppCode { get; set; }
        public string Track { get; set; }
        public string Groups { get; set; }
    }
}
