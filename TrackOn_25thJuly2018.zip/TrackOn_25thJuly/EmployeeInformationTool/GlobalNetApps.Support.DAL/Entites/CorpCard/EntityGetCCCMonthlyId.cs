﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityGetCCCMonthlyId
    {
        public int CCCMonthly_ID { get; set; }
    }
}
