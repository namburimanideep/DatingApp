﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace GlobalNetApps.Support.DAL.Entites
{
    public class EntityCorpCardInfo
    {
        public int TER_Num { get; set; }
        public int Seq_num { get; set; }
        public string cm_name { get; set; }
        public int emp_id { get; set; }
        public string bill_acct_num { get; set; }
        public string charge_dt { get; set; }
        public string insert_date { get; set; }
        public string billdate { get; set; }
        public string insert_dt { get; set; }
        public string Status { get; set; }
        public string CCCMonthly_ID { get; set; }
        public string update_date { get; set; }
        public string managername { get; set; }
        public string manageremail { get; set; }
        public string cardtype { get; set; }
        public string businesspurposes { get; set; }
        public string emp_type { get; set; }
        public string dflt_grp_nm { get; set; }
        public string amount { get; set; }
        public string localamount { get; set; }
        public string description { get; set; }
    }
}
