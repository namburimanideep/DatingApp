﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;
using System.Data;

namespace GlobalNetApps.Support.DAL.Interfaces
{
    public interface IEffortTracker
    {
        List<Entity_Rpt_Incident> getEntireTrackData(string userName, int getAllData);
        List<Entity_Rpt_Incident> getDashBoard(EntityGetDashBoard entityDashBoard);
        List<Entity_Rpt_GetDashBoardByGrouping> getReport(EntityGetDashBoard entityDashBoard);
        List<EntityMasterTable> getMasterDataFromSP(string username, string storeProc);
        List<EntityMasterTable> getMasterData(string inputQuery);
        List<EntityMasterTable> getApplication(string userName);
        List<EntityMasterTable> getRoles(string userName);
        List<EntityMasterTable> getName(string userName);
        List<EntityMasterTable> getTypeOfIncident(string userName);
        List<EntityMasterTable> getRootCause(string userName);
        List<EntityMasterTable> getResolution(string userName);        
        List<EntityMasterTable> getEffortType(string userName);
        List<EntityMasterTable> getTrackId(string userName);
        List<EntityMasterTable> getIncidentDropDown(string userName);
        List<EntityMasterTable> getTypeOfIncident(int trackId);
        List<EntityMasterTable> getReports();
        List<EntityMasterTable> getStatus();
        List<EntityMasterTable> getAlertType();
        List<EntityMasterTable> getPriority();
        List<EntityMasterTable> getSeverity();
        List<EntityMasterTable> getTracks();       
        int updateEffort(EntityEffort entityEffort);
        int deleteEffort(int effortId);
        EntityEffort addEfforts(EntityEffort addEffort);
        List<EntityMasterTable> getOpenIncidentForTrack(string UserName);
        List<EntityIncidentHistory> getHistory(int incidentId);
        int UpdateIncident(EntityIncidentHistory entityIncidentHistory);
        List<EntitySLA> GetDetailsForSLA(string username);
        int UpdateSLATimings(List<EntitySLA> lstSLA);
    }
}
