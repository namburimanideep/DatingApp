﻿

namespace GlobalNetApps.Support.DAL
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IRepository<T>
    {
        /// <summary>
        /// The Add
        /// </summary>
        /// <param name="item">item parameter which needs to be added</param>
        /// <returns>item parameter</returns>
        T Add(T item);

        Task<T> AddAsync<Y>(T item);

        /// <summary>
        /// Removes the record by the ID
        /// </summary>
        /// <param name="item">item parameter which needs to be remove</param>
        bool Remove(int id, object keyColumn);

        /// <summary>
        /// The update.
        /// </summary>
        /// <param name="item">item parameter which needs to be updated</param>
        T Update(T item, object keyColumn);

        Task<bool> UpdateAsync(T item);
    }
}


