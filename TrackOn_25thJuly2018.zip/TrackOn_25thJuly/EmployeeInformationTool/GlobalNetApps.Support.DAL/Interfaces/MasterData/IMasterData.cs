﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;

namespace GlobalNetApps.Support.DAL.Interfaces
{
    public interface IMasterData
    {
        List<EntityAssociates> GetAssociates();
        int AddAssociates(EntityAssociates entityAssociate);
        int UpdateAssociates(EntityAssociates entityAssociate);
        int DeleteAssociates(int Id);
    }
}
