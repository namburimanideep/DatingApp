﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;

namespace GlobalNetApps.Support.DAL.Interfaces
{
    public interface ITomsInfo
    {
        List<EntityTomsInfo> GetTomsInfo(string tomsEmpIDByComma);
    }
}
