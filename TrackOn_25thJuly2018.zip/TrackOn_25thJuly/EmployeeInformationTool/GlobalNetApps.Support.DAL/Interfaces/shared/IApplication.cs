﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;
using System.Data;

namespace GlobalNetApps.Support.DAL.Interfaces
{
    public interface IApplication
    {
        List<EntityApplications> getApplicationDetails();
    }
}
