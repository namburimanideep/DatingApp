﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalNetApps.Support.DAL.Entites;


namespace GlobalNetApps.Support.DAL.Interfaces
{
    public interface ICorpCardCharges_dev
    {
        List<EntityGetCCCMonthlyId> GetCCCMonthly_ID(string oldempId, string newempId, string query);
    }
}
